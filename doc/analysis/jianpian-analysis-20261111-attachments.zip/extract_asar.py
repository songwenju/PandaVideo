import hashlib
import json
from pathlib import Path
import struct

root = Path(__file__).resolve().parent
data = (root / 'input/app.asar').read_bytes()
header_size = struct.unpack_from('<I', data, 4)[0]
json_size = struct.unpack_from('<I', data, 12)[0]
header = json.loads(data[16:16 + json_size])
base = 8 + header_size
dest = root / 'extracted'
inventory = []

def walk(files, prefix=Path()):
    for name, entry in files.items():
        rel = prefix / name
        target = (dest / rel).resolve()
        if not target.is_relative_to(dest.resolve()):
            raise ValueError('Unsafe archive path')
        if 'files' in entry:
            walk(entry['files'], rel)
            continue
        row = {'path': str(rel), **entry}
        if entry.get('unpacked') or 'link' in entry:
            row['extraction_status'] = 'external_or_link_not_extracted'
        else:
            start = base + int(entry['offset'])
            size = int(entry['size'])
            if start < base or start + size > len(data):
                raise ValueError('Invalid file bounds')
            payload = data[start:start + size]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
            row['sha256'] = hashlib.sha256(payload).hexdigest()
            row['extraction_status'] = 'extracted'
        inventory.append(row)

walk(header['files'])
(root / 'asar_inventory.json').write_text(json.dumps(inventory, indent=2))
print(json.dumps({'files': len(inventory), 'external': sum(x['extraction_status'] != 'extracted' for x in inventory), 'data_offset': base}))
