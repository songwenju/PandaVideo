from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'analysis_dependencies'))
import jsbeautifier

for source in (root / 'extracted/dist/assets').glob('*.js'):
    target = root / 'formatted/dist/assets' / source.name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(jsbeautifier.beautify(source.read_text()))
print('Formatted derived copies; extracted sources unchanged.')
