import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
runner = root.parents[1] / 'tools/_run.sh'

def state(command, *args):
    result = subprocess.run(['bash', str(runner), 'analysis_state', command, str(root), *map(str, args)], capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr + result.stdout)

def latest(name, key):
    rows = [json.loads(line) for line in (root / name).read_text().splitlines() if line.strip()]
    return {row[key]: row for row in rows}

claims = latest('claim_ledger.jsonl', 'claim_id')
bundles = latest('evidence_bundles.jsonl', 'bundle_id')
main = 'formatted/dist/assets/index-B33oKSXv.js'
paths = {
    'C-DOMAINS': [(main, 21174, 21180), (main, 15207, 15215), (main, 12699, 12705), (main, 12506, 12515), (main, 12481, 12489)],
    'C-AUTH': [(main, 21174, 21180), (main, 12797, 12800), (main, 12706, 12716), (main, 12815, 12834)],
    'C-PAGES': [(main, 21350, 21354), ('formatted/dist/assets/Search-Cfs0L6Gc.js', 190, 205), (main, 21719, 21735), (main, 12699, 12716)],
    'C-PLAY': [(main, 21359, 21366), ('formatted/dist/assets/Detail-D9nBaeLj.js', 653, 683), (main, 15039, 15064), (main, 15079, 15086), ('formatted/dist/assets/VideoPlayer-9YDDWVER.js', 27514, 27524)],
    'C-HISTORY': [('formatted/dist/assets/VideoPlayer-9YDDWVER.js', 27525, 27535), ('formatted/dist/assets/Detail-D9nBaeLj.js', 724, 736), (main, 22033, 22047)],
    'C-UPDATE': [('formatted/dist/assets/CheckUpdate-DSfI3V6P.js', 54, 68), (main, 15197, 15203), (main, 21184, 21199), ('formatted/dist/assets/Update-BJPw7HGw.js', 59, 70), ('extracted/src/main/event-handlers.js', 55, 75), ('extracted/src/main/utils.js', 20, 39)]
}
path_rows = []
for cid, segments in paths.items():
    row = {'claim_id': cid, 'path_id': claims[cid]['path_id'], 'kind': 'static_call_chain', 'dynamic_verified': False, 'segments': []}
    for file, start, end in segments:
        excerpt = '\n'.join((root / file).read_text().splitlines()[start-1:end])
        row['segments'].append({'file': file, 'line_start': start, 'line_end': end, 'excerpt': excerpt,
                                'excerpt_sha256': hashlib.sha256(excerpt.encode()).hexdigest()})
    path_rows.append(row)
(root / 'static_paths.json').write_text(json.dumps(path_rows, ensure_ascii=False, indent=2))

for number, cid in enumerate(claims, 1):
    claim = claims[cid]
    bundle = bundles[f'B-{number}']
    evidence_ids = claim['evidence_ids']
    if cid in paths:
        eid = f'E-PATH-{number}'
        state('evidence', '--id', eid, '--level', 'E3', '--kind', 'call_chain', '--summary', claim['claim'],
              '--file', root / 'static_paths.json', '--line', 1, '--path-id', claim['path_id'], '--artifact-id', 'A-ASAR', '--tool', 'static_source_call_chain_review')
        evidence_ids = [f'E-{number}', eid]
        state('claim', '--id', cid, '--text', claim['claim'], '--importance', claim['importance'],
              '--level', 'E3', '--required-level', 'E3', '--domain', claim['domain'], '--status', 'proven',
              '--evidence', ','.join(evidence_ids), '--scope', claim['scope'], '--confidence', 'high',
              '--path-id', claim['path_id'], '--provenance', claim['provenance'], '--conditions', claim['conditions'],
              '--counter-evidence', claim['counter_evidence'], '--coverage', claim['coverage'],
              '--dynamic-gap', claim['dynamic_gap'], '--no-dynamic-needed', '--dynamic-priority', 'none')
        state('evidence-bundle', '--id', bundle['bundle_id'], '--claim-id', cid, '--finding', claim['claim'],
              '--leads', f'L-{number}', '--static-evidence', ','.join(evidence_ids), '--path-id', claim['path_id'],
              '--code-evidence', f'CB-{number}', '--allowed-conclusion', claim['claim'],
              '--forbidden-expansion', claim['counter_evidence'], '--report-summary', claim['claim'],
              '--technical-refs', 'static_paths.json')

outline = json.loads((root / 'report_outline_input.json').read_text())
outline['narrative'] = {'primary_flow': 'static_first', 'standalone_dynamic_chapter': False,
                        'technical_detail_routing': 'layered', 'critical_code_in_body': True,
                        'duplicate_runtime_sections': False}
for number, finding in enumerate(outline['findings'], 1):
    cid = finding['claim_id']
    finding.update({'static_summary': claims[cid]['claim'], 'body_section': cid,
                    'technical_refs_section': '交付与证据索引', 'evidence_bundle_id': f'B-{number}',
                    'code_evidence_block_ids': [f'CB-{number}']})
(root / 'report_outline_input.json').write_text(json.dumps(outline, ensure_ascii=False, indent=2))
state('report-outline', '--input', root / 'report_outline_input.json')
print('Registered source-backed static paths and linked report findings.')
