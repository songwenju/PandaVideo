import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
template = (root / 'report_template.md').read_text()
blocks = (root / 'code_evidence.md').read_text().split('### C-')[1:]
for index, block in enumerate(blocks, 1):
    template = template.replace('{{CB' + str(index) + '}}', '### C-' + block.strip())
if '{{CB' in template:
    raise ValueError('Unresolved evidence block')
template = template.replace('HTTP(S) 直播', 'HTTP(S) 直链播放')
(root / 'jianpian_report.md').write_text(template)

rows = []
def add(purpose, method, host, path, parameters, response, evidence, status='static_confirmed'):
    rows.append({'id': f'AUX-{len(rows)+1:02}', 'purpose': purpose, 'method': method, 'host': host,
                 'path': path, 'parameters': parameters, 'response_consumer_contract': response,
                 'evidence': evidence, 'static_status': status, 'dynamic_status': 'not_verified'})

main = 'formatted/dist/assets/index-B33oKSXv.js'
add('域名探活', 'GET', 'candidate_base', '/api/v2/settings/appAuthConfig', {}, 'code=1 accepted', main + ':12436')
add('域名列表文件', 'GET', 'jdomain.oss-accelerate.aliyuncs.com', '/domain.txt', {}, 'comma-separated text', main + ':12472')
for host, path in [('dns.alidns.com', '/resolve'), ('doh.pub', '/dns-query'), ('1.1.1.1', '/dns-query')]:
    add('DNS TXT discovery', 'GET', host, path, {'name': 'pyvemnlu.cc', 'type': 16, 'Accept': 'application/dns-json'},
        'Answer[0].data -> JSON.parse -> split comma; compatibility unverified', main + ':12453')
commands = {'create': ('resource_b64url', 'none', 'text'), 'pause': ('resource_b64url', 'none', 'text'),
            'resume': ('resource_b64url', 'none', 'text'), 'cancel': ('resource_b64url', 'none', 'text'),
            'delete': ('resource_b64url', 'none', 'text'), 'get_download_speed': ('resource_b64url', 'none', 'numeric text, unit unverified'),
            'get_size': ('resource_b64url', 'none', 'numeric text / ERR Not Found Task'),
            'get_downloaded_size': ('resource_b64url', 'none', 'numeric text / ERR Not Found Task'),
            'setpath': ('', 'raw directory string', 'text'), 'set_p2p_play_timeout': ('', 'JSON timeout value', 'unverified text'),
            'get_task_list': ('', 'none', 'unverified text')}
for cmd, (resource, body, response) in commands.items():
    add('本地引擎控制', 'POST', 'http://127.0.0.1:{port}; default=5800', '/api/v1/' + cmd + ('/{resource_b64url}' if resource else ''),
        {'resource': resource, 'body': body, 'token': 'not attached', 'signature': 'not attached'}, response,
        main + ':15039', 'wrapper_only' if cmd in ('set_p2p_play_timeout', 'get_task_list') else 'static_implementation')
add('本地媒体播放', 'GET expected media request', 'http://127.0.0.1:{port}', '/p2p/{resource_b64url}',
    {'resource': 'UTF8 base64url unpadded', 'Range': 'unverified'}, 'media bytes; app declares video/mp4', main + ':15079')
add('统计SDK加载', 'GET browser script', 'https://d.alicdn.com', '/alilog/mlog/aplus/203467608.js', {}, 'external JavaScript, not fetched', 'extracted/dist/index.html:16')
add('统计兼容重定向', 'not established', 'umini.shujupie.com', 'file:// to https:// same path', {},
    'none; only request-redirection handler found', 'extracted/src/main/index.js:221', 'redirect_rule_only')
for kind, start in [('普通图片', 21460), ('广告图片', 21476)]:
    add(kind, 'GET browser image', 'https://{imgDomain_selected}', '{original_path_query_hash}', {},
        'image bytes; dynamic host returned by resource config', main + f':{start}')
add('长视频直链', 'GET expected media requests', 'server_returned', 'source_list_source[].source_list[].url',
    {'VHS token': 'only if isVip; vipSwitch=false', 'Range/playlist/segment headers': 'not verified'},
    'media data; actual format and hosts unverified', 'formatted/dist/assets/Detail-D9nBaeLj.js:658')
add('短视频直链', 'GET expected media requests', 'server_returned', 'short_detail.url', {},
    'media data; hosts unverified', 'formatted/dist/assets/ShortDetail-Be5VM2Wq.js:343')
add('更新包', 'GET via Node https.get', 'version_info.url server-returned HTTPS URL', '{package_path}',
    {'User-Agent': 'fixed Windows Chrome/120 UA', 'token': 'not attached', 'signature': 'not attached'},
    'file bytes; content-length used for progress; no status-code or hash checks in reviewed helper', 'extracted/src/main/utils.js:20')
add('字幕脚本候选', 'GET conditional library script loader', 'https://vjs.zencdn.net', '/vttjs/0.14.1/vtt.min.js', {},
    'third-party fallback library path; actual loading not verified', 'formatted/dist/assets/VideoPlayer-9YDDWVER.js', 'third_party_conditional')
(root / 'network_auxiliary.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))

bad = []
for prefix, name, line in re.findall(r'([FSH]):([A-Za-z0-9_./-]+):(\d+)', template):
    base = root / ('formatted/dist/assets' if prefix == 'F' else 'extracted/src')
    path = base / name
    if not path.exists() or int(line) > len(path.read_text().splitlines()):
        bad.append(f'{prefix}:{name}:{line}')
if bad:
    raise ValueError('Invalid source references: ' + ','.join(bad))
print(json.dumps({'report_lines': len(template.splitlines()), 'auxiliary_channels': len(rows), 'source_reference_check': 'passed'}))
