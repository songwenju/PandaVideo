import csv
import gc
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'analysis_dependencies'))
from tree_sitter import Language, Parser
import tree_sitter_javascript

parser = Parser(Language(tree_sitter_javascript.language()))
gc.disable()
main = root / 'formatted/dist/assets/index-B33oKSXv.js'
classes = {'tg': '影视与发现', 'YR': '短视频', 'nn': '账号与互动', 'm7': '广告', 'wo': '配置与更新'}
exports = {'V': 'tg', 'S': 'YR', 'C': 'nn', 'at': 'm7', 'ay': 'wo', 'aj': 'Wt'}
units = {}

def visit(node):
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))

def text(node, data):
    return data[node.start_byte:node.end_byte].decode() if node else ''

for path in (root / 'formatted/dist/assets').glob('*.js'):
    data = path.read_bytes()
    tree = parser.parse(data)
    if tree.root_node.has_error:
        raise ValueError(f'JavaScript parse errors: {path.name}')
    aliases = dict((k, k) for k in classes) if path == main else {}
    if path != main:
        for node in visit(tree.root_node):
            if node.type != 'import_statement':
                continue
            source = node.child_by_field_name('source')
            if not source or 'index-B33oKSXv.js' not in text(source, data):
                continue
            for spec in visit(node):
                if spec.type == 'import_specifier':
                    name = text(spec.child_by_field_name('name'), data)
                    alias = text(spec.child_by_field_name('alias'), data) or name
                    if name in exports:
                        aliases[alias] = exports[name]
    units[path] = (data, tree, aliases)

caller_index = {}
for path, (other, other_tree, aliases) in units.items():
    for candidate in visit(other_tree.root_node):
        if candidate.type != 'call_expression':
            continue
        f = candidate.child_by_field_name('function')
        if not f or f.type != 'member_expression':
            continue
        obj = text(f.child_by_field_name('object'), other)
        prop = text(f.child_by_field_name('property'), other)
        if obj in aliases:
            caller_index.setdefault((aliases[obj], prop), []).append({
                'file': str(path.relative_to(root)), 'line': candidate.start_point.row + 1,
                'call': text(candidate, other)})

data, tree, _ = units[main]
rows = []
for node in visit(tree.root_node):
    if node.type != 'method_definition':
        continue
    parent = node.parent.parent
    if parent.type != 'class_declaration':
        continue
    cls = text(parent.child_by_field_name('name'), data)
    if cls not in classes:
        continue
    method = text(node.child_by_field_name('name'), data)
    for call in visit(node):
        if call.type != 'call_expression':
            continue
        fun = call.child_by_field_name('function')
        if text(fun, data) not in ('ne.get', 'ne.post'):
            continue
        args = call.child_by_field_name('arguments').named_children
        options = args[1] if len(args) > 1 else None
        fields = {}
        if options and options.type == 'object':
            for pair in options.named_children:
                if pair.type == 'pair':
                    fields[text(pair.child_by_field_name('key'), data)] = text(pair.child_by_field_name('value'), data)
        callers = caller_index.get((cls, method), [])
        rows.append({'id': f'API-{len(rows)+1:03}', 'purpose': classes[cls], 'symbol': f'{cls}.{method}',
                     'method': text(fun, data).split('.')[1].upper(), 'base': 'selected_base/api',
                     'path_expression': text(args[0], data), 'query': fields.get('params', ''),
                     'body': fields.get('data', ''), 'config': fields.get('config', ''),
                     'signature': 'MD5(version + timestamp + sys_init.secret); version=504; exceptions in config',
                     'authentication': 'U1(raw_path): v2 token header; legacy GET token query / POST token body',
                     'response': 'code=1 required; data unwrapped unless originalData=true; full server schema unverified',
                     'source': str(main.relative_to(root)), 'line': call.start_point.row + 1,
                     'method_start': node.start_point.row + 1, 'method_end': node.end_point.row + 1,
                     'original_file': 'extracted/dist/assets/index-B33oKSXv.js',
                     'static_status': 'caller_found' if callers else 'wrapper_only',
                     'dynamic_status': 'not_verified', 'callers': callers,
                     'implementation': text(node, data)})

(root / 'network_interfaces.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
with (root / 'network_interfaces.csv').open('w') as f:
    keys = ['id', 'purpose', 'symbol', 'method', 'path_expression', 'query', 'body', 'config', 'static_status', 'dynamic_status', 'source', 'line']
    writer = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)

md = ['# 荐片 macOS 5.0.4 · 网络接口逐项清单', '', '## 结论', '',
      f'本清单从实际附件 JavaScript AST 提取 {len(rows)} 个业务请求封装；仅描述静态代码，未发送这些请求。', '',
      '|事项|结论|', '|---|---|', '|目标|附件 app.asar，package.json version=5.0.4|',
      '|动态请求|0 项完成运行验证；所有响应均为客户端消费契约，不是实测响应|',
      '|路径规则|相对路径前加 selected_base + /api；模板和查询拼接保留原表达式|', '',
      '## 阅读约定', '', 'caller_found 只表示存在静态调用点，不保证每个开关或分支均可运行；wrapper_only 不认定页面已启用。参数右侧为封装函数的局部变量，请结合原方法签名和调用点查看实际来源。', '',
      'GET 的 params 为查询参数，POST 的 data 通常按 application/x-www-form-urlencoded 序列化。正常签名头为 version=504、timestamp=秒级时间、signature=MD5("504"+timestamp+secret)。secret 来自 /api/v2/sys/init；该初始化及域名探活不签名。token 是否附加由 U1 对原始 URL 字符串精确比较决定，不能以“公开接口”自行推断。', '',
      '响应封装要求 code=1，否则拒绝 {code,msg}；originalData=true 返回原对象，其他通常返回 data。没有服务端样本，所有完整 schema、可选字段、实际值及鉴权效果均未验证。下列调用点包含真实源文件行号；formatted 是只改变排版的派生副本，原压缩文件保留在 extracted，行号通常为 1。', '']
for purpose in classes.values():
    md += ['## ' + purpose, '']
    for row in rows:
        if row['purpose'] != purpose:
            continue
        md += [f"### {row['id']} {row['symbol']}", '', f"- 请求：`{row['method']}` `{row['path_expression']}`。",
               f"- 状态：静态 {row['static_status']}；动态未验证。",
               f"- 定位：`{row['source']}:{row['line']}`。"]
        for name, key in [('查询', 'query'), ('请求体', 'body'), ('特殊配置', 'config')]:
            if row[key]:
                md += [f'- {name}：', '```javascript', row[key], '```']
        md += ['- 调用点：' + ('；'.join(f"`{c['file']}:{c['line']}`" for c in row['callers']) or '未找到；仅保留封装候选。'),
               '- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。', '']
(root / 'network_interfaces.md').write_text('\n'.join(md))
print(json.dumps({'business_wrappers': len(rows), 'caller_found': sum(bool(r['callers']) for r in rows),
                  'wrapper_only': sum(not r['callers'] for r in rows), 'parsed_js_files': len(units)}))
