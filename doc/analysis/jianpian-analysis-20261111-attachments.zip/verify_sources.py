import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'analysis_dependencies'))
from tree_sitter import Language, Parser
import tree_sitter_javascript
parser = Parser(Language(tree_sitter_javascript.language()))

def fingerprint(path):
    data = path.read_bytes()
    tree = parser.parse(data)
    if tree.root_node.has_error:
        raise ValueError('Parse error in ' + path.name)
    stack = [tree.root_node]
    tokens = []
    while stack:
        node = stack.pop()
        if node.type == 'comment':
            continue
        if not node.children:
            tokens.append((node.type, data[node.start_byte:node.end_byte].decode()))
        else:
            stack.extend(reversed(node.children))
    return hashlib.sha256(json.dumps(tokens, ensure_ascii=False).encode()).hexdigest()

results = []
for source in (root / 'extracted/dist/assets').glob('*.js'):
    derived = root / 'formatted/dist/assets' / source.name
    a, b = fingerprint(source), fingerprint(derived)
    results.append({'file': source.name, 'original_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                    'formatted_sha256': hashlib.sha256(derived.read_bytes()).hexdigest(),
                    'lexical_tokens_equal': a == b, 'token_fingerprint': a})
(root / 'source_verification.json').write_text(json.dumps(results, indent=2))
print(json.dumps({'files': len(results), 'matching': sum(r['lexical_tokens_equal'] for r in results)}))
if not all(r['lexical_tokens_equal'] for r in results):
    raise SystemExit(1)
