### C-DOMAINS

<!-- CODE_EVIDENCE:CB-1 -->
**调用链：** App → getSysInit → HTTP base resolver → p7 → candidate probe

```javascript
async function p7() {
    let e = c7(),
        t = await u0(e);
    if (t) return t;
    for (let n of p2)
        if (e = await d7(n), !!e && (localStorage.setItem(mf, JSON.stringify(e)), t = await u0(e), t)) return t;
    for (let n of o7)
        if (e = await f7(n), !!e && (localStorage.setItem(mf, JSON.stringify(e)), t = await u0(e), t)) return t;
    return e = h7(), t = await u0(e), t || null
}
```

**证明关系：** 证明候选选择顺序和缓存写入逻辑。
**证据边界：** 不证明候选当前存活或运行时选中了哪个域名。
**定位：** p7；E-1；formatted/dist/assets/index-B33oKSXv.js:12506；Bundle B-1；Path P-1。

### C-AUTH

<!-- CODE_EVIDENCE:CB-2 -->
**调用链：** App.getSysInit → setSecret → page API → request interceptor → Axios

```javascript
                const n = Uo();
                t.method == "get" ? t.params.token = n.token : t.method == "post" && (t.data instanceof FormData ? t.data.append("token", n.token) : t.data.token = n.token)
            }
            if (!t.options.noSignature) {
                const n = await un(this, qo),
                    i = Math.floor(new Date().getTime() / 1e3),
                    o = "504",
                    a = t7.MD5(o + i + n).toString();
                t.headers.version = o, t.headers.timestamp = i, t.headers.signature = a
            }
            return t
```

**证明关系：** 证明 token 放置分支、MD5 输入与签名请求头。
**证据边界：** 不证明服务端鉴权有效性，secret 的实际值和完整响应未知。
**定位：** ys.request interceptor；E-2；formatted/dist/assets/index-B33oKSXv.js:12706；Bundle B-2；Path P-2。

### C-PAGES

<!-- CODE_EVIDENCE:CB-3 -->
**调用链：** Home → Search route → Search.d → tg.search → Axios

```javascript
                    D(!0);
                    const {
                        data: i,
                        total: y
                    } = await B.search({
                        id: (t = e.value[r.value]) == null ? void 0 : t.id,
                        key: p.value,
                        page: c.value
                    });
                    (i == null ? void 0 : i.length) > 0 ? (s.value.push(...i), c.value++) : P().error("没有更多了"), l.value = y
                } catch (i) {
                    console.log(i)
```

**证明关系：** 证明搜索以分类、关键词和页码调用业务接口并消费结果。
**证据边界：** 不证明接口当前可用或界面运行结果，搜索响应为客户端消费契约。
**定位：** Search.d；E-3；formatted/dist/assets/Search-Cfs0L6Gc.js:193；Bundle B-3；Path P-3。

### C-PLAY

<!-- CODE_EVIDENCE:CB-4 -->
**调用链：** Detail → source_list.url → Tn.getPlayUrl → local engine → VideoPlayer

```javascript
                    if (!D.startsWith("http")) {
                        t = D, A.ready = !1, A.status = "资源获取中···";
                        try {
                            ge.getPlayUrl(D).then(async E => {
                                await new Promise(Se => setTimeout(Se, 2e3)), A.srcs = [{
                                    src: E,
                                    type: "video/mp4"
                                }], A.status = ""
                            }).catch(() => {
                                A.status = "资源获取失败"
                            }).finally(() => {
                                A.ready = !0
```

**证明关系：** 证明非 HTTP 分支取得本地播放 URL，并以 video/mp4 提供给播放器。
**证据边界：** 包外 JPEngine2 未提供，不能证明上游协议、节点、资源可播或媒体真实格式。
**定位：** Detail source watchEffect；E-4；formatted/dist/assets/Detail-D9nBaeLj.js:669；Bundle B-4；Path P-4。

### C-DOWNLOAD

<!-- CODE_EVIDENCE:CB-5 -->
**调用链：** embedded downloadSelect.m (opening path unconfirmed) → TR.download → task scheduler

```javascript
            localStorage.setItem(`cache-video-datail-${w.id}`, JSON.stringify(w)), y = y.filter(A => !n.value.find(v => v.url == A.url)), y = y.map(A => (A.cateId = w.cate_id, A.cover ?? (A.cover = w.thumbnail), {
                speed: 0,
                progress: 0,
                status: 0,
                fileSize: 0,
                url: A.url,
                type: A.url.startsWith("ftp://") ? 1 : 0,
                videoInfo: A
            })), n.value.push(...y)
        }
        async function u(y) {
            const w = n.value.findIndex(A => A.url == y);
            if (w != -1) {
```

**证明关系：** 证明缓存元数据持久化、URL 去重及仅 FTP 分类为可调度下载类型。
**证据边界：** 选集弹窗没有发现开启入口；不能宣称本版本下载页面可用或下载已完成。
**定位：** TR.download；E-5；formatted/dist/assets/index-B33oKSXv.js:21039；Bundle B-5；Path P-5。

### C-HISTORY

<!-- CODE_EVIDENCE:CB-6 -->
**调用链：** VideoPlayer unmount playEnd → Detail.U → Detail.a → tg.addPlayRecord

```javascript
            }
            async function a(s, i) {
                var c, f, g, D, A;
                if (x.isLogin) try {
                    await Z.addPlayRecord(1, m, (c = r.value) == null ? void 0 : c.title, w.value, ((f = J.value) == null ? void 0 : f.name) ?? "", ((g = Y.value) == null ? void 0 : g.source_name) ?? "", s, i, (D = r.value) == null ? void 0 : D.cate_id, (A = r.value) == null ? void 0 : A.thumbnail)
                } catch (E) {
                    console.log(E.msg)
                }
            }

            function U(s, i) {
                a(s, i)
            }
```

**证明关系：** 证明登录条件下提交影视来源及播放时长到服务端历史接口。
**证据边界：** 不证明请求实际发送、服务端保存成功或跨设备同步结果。
**定位：** Detail.a/U；E-6；formatted/dist/assets/Detail-D9nBaeLj.js:724；Bundle B-6；Path P-6。

### C-UPDATE

<!-- CODE_EVIDENCE:CB-7 -->
**调用链：** manual check → wo.getVersion(undefined) → pc_download_url → VersionInfo → Update.download

```javascript
                    const {
                        versioncode: e,
                        pc_download_url: t,
                        text: f
                    } = await g.getVersion();
                    y.setStoreValue("VersionInfo", {
                        version: e,
                        url: t,
                        desc: f
                    }), _.value = e, a.value = V(e, o.version)
                } catch (e) {
                    console.log(e)
                } finally {
                    c.value = !1
```

**证明关系：** 证明手动检查未传 mac 平台 id，并把 PC URL 写入更新信息。
**证据边界：** 服务端可能调整响应；没有 macOS 运行证据，不宣称必然安装错误包。
**定位：** CheckUpdate mounted handler；E-7；formatted/dist/assets/CheckUpdate-DSfI3V6P.js:54；Bundle B-7；Path P-7。
