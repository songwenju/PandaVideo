# 荐片 macOS 5.0.4 · 实际 ASAR 功能、网络接口与播放缓存链路

目标：用户指定的 `com.jianpian.macos`；附件 `app.asar`；分析日期：2026-11-11。附件内 `package.json` 确认名称 `jianpian`、版本 `5.0.4`、入口 `src/main/index.js`，但 ASAR 不含 `Info.plist`，无法独立核对 bundle identifier、应用签名或 Electron 运行时版本。

## 结论

**本附件实现了服务端驱动的影视浏览、分类、搜索、详情及播放器；非 HTTP 播放依赖包外 `JPEngine2`，下载逻辑存在但正常界面入口未确认。所有网络结论为静态代码确认，动态验证请求为 0。**

|关键发现|关注标识与意义|证据与边界|
|---|---|---|
|首页、分类、搜索、详情、短视频、上映表、专题、排行榜、求片榜、个人中心存在真实路由与调用点|重点关注：本 macOS 附件的产品功能|E2/E3；不是同名 Android 实现|
|业务服务器经缓存、固定域名、远程列表、DNS TXT 和日期派生候选发现|重点关注：接口域名不能固定成一个常量|E3；实际选中域名未验证|
|业务签名为 MD5(版本号 + 秒级时间戳 + 初始化 secret)，用户 token 按原始 URL 规则注入|重点关注：请求契约与初始化依赖|E3；secret 实际值和服务端鉴权效果未知|
|HTTP 媒体直接播放，其他资源经本地引擎生成 MP4 地址；FTP 类型可进入下载调度|重点关注：媒体控制面与传输面分离|E2/E3；未提供原生引擎，不能还原上游节点协议|
|收藏与历史使用云端接口；启动更新和手动检查更新使用不同的平台字段选择|持续观察：登录依赖及 macOS 更新兼容性|E3；不宣称云端保存或安装已成功|

质量状态：`limited`，限制来自缺少 macOS 运行环境、完整应用外壳和 `JPEngine2`。报告不把未覆盖范围写成“未发现”，不对本功能研究做风险定级。质量冻结结果另附 `quality_status.json`，不能由发布成功推断证据门禁通过。

## 样本与证据口径

- ASAR：10,417,170 字节；SHA-256：`c8b0d5c2fe0843da97d2a763d329cc4bae079e71456450e3f6eb531236d191d5`；MD5：`f4600dbb8935c85637d3e5bf11d86ca2`。
- 已校验 ASAR 路径与字节边界并解包 786 个文件，无 `unpacked` 外置条目或链接条目；这不意味着应用没有包外依赖，启动代码明确引用包外引擎。
- 56 个 `dist/assets/*.js` 均通过 JavaScript 语法解析；格式化副本与原文件逐词法 token 校验结果见 `source_verification.json`。没有执行附件业务代码，没有请求业务服务器，也没有下载影视资源。
- 截图仅为 182×40 的“荐片”图标与名称，不能证明页面、播放状态或版本。平台和 bundle identifier 以用户提供信息为准。
- 静态实现 E2：存在可复核函数；静态链路 E3：找到入口、条件及请求/播放 sink；动态 E4/E5：本次均没有。`caller_found` 仅说明找到调用点，不保证开关开启或用户能进入该分支。
- 本环境实测为 Linux，没有授权 macOS 目标会话及 macOS 应用外壳；未提供 `JPEngine2`。因此无法进行真实启动、界面复现、抓包、媒体播放或缓存落盘验证，也没有用 Android 应用代替。

以下 `F:` 表示 `formatted/dist/assets/` 内的可读派生副本；`S:` 表示 `extracted/src/`；`H:` 表示 `extracted/dist/index.html`。原压缩代码在 `extracted/dist/assets/`，大部分函数位于原文件第 1 行；报告行号均明确引用 F 副本，不能冒充原开发源码行号。

## 主要页面与功能

|页面或功能|静态实现与入口|主要文件证据|
|---|---|---|
|首页与分类导航|`/` 默认跳到 `/category?id=88&name=推荐`；导航由 homeCategory 返回，另追加短视频与发现|F:index-B33oKSXv.js:21281；F:Home-HYqkCKsk.js:48|
|分类首页|轮播 `/slide/list`、子类 `/customTags/list`、推荐模块 `/pc_dyTag/list`；按模板取影视卡片，每组默认 count=8，第一页混入人工推荐 hand_data，支持分页/换一换|F:Category-aMbhBLHJ.js:284、310、319、325、341|
|全部分类|`/videos/category` 读取筛选项 `{key,data:[{id,name}]}`；选值作为动态查询键，分页请求 crumb/list；`fcate_pid=67` 走 shortList；500ms 防抖和 AbortController 取消旧请求|F:CategoryFilter-lllrC5Dm.js:137、163、190|
|搜索|`/search/:keyword`；分类标签、关键词高亮、总数与滚动加载；按 key/category_id/page 搜索；搜索输入候选和本地搜索历史另在顶部 Search 组件|F:Search-Cfs0L6Gc.js:175、196；F:Action-DoKrXy2x.js:214、266|
|长视频详情|`/detail/:id`；评分、类型、导演、主演、地区、年代、介绍、相关推荐、来源线路、分集、收藏、评论；按 source.id 与 episode.weight 选择|F:Detail-D9nBaeLj.js:574、608、650、711；简介渲染:494|
|在线播放|详情组装 sources，Video.js 显示播放、暂停、进度、音量、倍速、上下集、换源、全屏、画中画及跳片头片尾；30 秒无就绪事件触发播放错误并尝试后续线路|F:VideoPlayer-9YDDWVER.js:27470、27542、27566、27618、27691；F:Detail-D9nBaeLj.js:634、747|
|短视频及短详情|`/short-video`、`/short-detail/:id`；列表 `/play` 与详情 `/detail` 提供 URL；垂直滑动、合集、点赞、收藏、分享、评论；URL 直接交给公共播放器|F:ShortVideo-CDQMB1dB.js:251、312、665、690；F:ShortDetail-Be5VM2Wq.js:319、343|
|发现|`/discover` 展示上映表、专题、排行榜、求片榜，默认上映表；另存在片单、放映室相关路由，但不是所有路由都有可见导航项|F:Discover-BzZ-VgvP.js:46；F:index-B33oKSXv.js:21311|
|上映表、专题、榜单、求片|上映表按年份与分页消费嵌套 sub；专题列表与详情可收藏；周榜按 category_id；求片列表、提交申请与点赞|F:HistoryRelease-DWD5fN7t.js:57、78；F:SpecialDetail-D8YInbxV.js；F:Ranking-DPccmXn-.js:96；F:RequestRanking-C1EjNOvp.js|
|收藏与观看历史|`/profile`；影片/专题/片单收藏，分页及批量删除；历史按 collection 分组删除，点击回到详情；进度上报仅登录时触发|F:Profile-Cor6JmxC.js:202、256、265、647、690；F:Detail-D9nBaeLj.js:724|
|下载/缓存|详情内嵌选集下载组件及持久化任务队列，但开关 l 初始 false，仅找到关闭赋值，未找到开启入口；未找到常规下载管理页面。顶部 download-popup 是移动端下载二维码，不是影视任务管理|F:Detail-D9nBaeLj.js:100、355、518；F:index-B33oKSXv.js:20979；F:Action-DoKrXy2x.js:1154、1453|
|设置与反馈|独立设置窗：开机自启、最小化位置、关闭行为、更新模式与恢复默认；反馈 POST content/contact/type/client。关闭行为读取 CloseStatus，自启走 Electron login-item API|F:SetUp-DPMSXjnW.js:80；S:main/index.js:177；S:main/event-handlers.js:100；F:Feedback-HwIxFkQh.js|
|更新|独立检查/更新窗；启动时按 Mac 取 mac_download_url，软件包由主进程 HTTPS 下载，再 openPath 并退出；手动检查路径存在 PC 字段不一致|F:index-B33oKSXv.js:21184；F:CheckUpdate-DSfI3V6P.js:54；S:main/event-handlers.js:55、87|

会员相关组件和支付封装虽存在，但全局配置 `vipSwitch: !1`。当前附件不能凭会员页面资产、协议文本或 VIP 参数宣称会员专线已开放；列表中这些请求保留静态调用/开关边界。

### C-PAGES

<!-- CODE_EVIDENCE:CB-3 -->
**调用链：** Home → Search route → Search.d → tg.search → Axios

```javascript
                    D(!0);
                    const {
                        data: i,
                        total: y
                    } = await B.search({
                        id: (t = e.value[r.value]) == null ? void 0 : t.id,
                        key: p.value,
                        page: c.value
                    });
                    (i == null ? void 0 : i.length) > 0 ? (s.value.push(...i), c.value++) : P().error("没有更多了"), l.value = y
                } catch (i) {
                    console.log(i)
```

**证明关系：** 证明搜索以分类、关键词和页码调用业务接口并消费结果。
**证据边界：** 不证明接口当前可用或界面运行结果，搜索响应为客户端消费契约。
**定位：** Search.d；E-3；formatted/dist/assets/Search-Cfs0L6Gc.js:193；Bundle B-3；Path P-3。

## 域名与请求用途

|用途|域名或 URL 模板|请求、数据及确认边界|证据|
|---|---|---|---|
|固定业务候选|`https://japi.zxfmj.com`|不是唯一或实测主域；候选探活 GET `/api/v2/settings/appAuthConfig`，noSignature=true，成功以公共 code=1 契约判定|F:index-B33oKSXv.js:12421、12436、12481|
|域名列表分发|`https://jdomain.oss-accelerate.aliyuncs.com/domain.txt`|Axios GET，无业务签名/token；响应代码预期为逗号分隔文本，保存 API_DOMAINS|同文件:12426、12472、12506|
|TXT 查询一|`https://dns.alidns.com/resolve`|GET，Accept=application/dns-json，name=pyvemnlu.cc，type=16；读取 Answer[0].data，先 JSON.parse 再 split(',')|同文件:12423、12453|
|TXT 查询二/三|`https://doh.pub/dns-query`、`https://1.1.1.1/dns-query`|沿用同一 DNS JSON 请求，不代表两端当前兼容该响应格式或实际成功|同文件:12423、12453|
|DNS 查询目标|`pyvemnlu.cc`|是查询参数 name，不是证实被直接 HTTP 请求的业务主机|同文件:12422、12463|
|远程域名候选|`https://{随机6位字母数字}.{候选域}`；IP 候选用 `http://{IP[:port]}`|先 LAST_VALID_API_DOMAIN/API_DOMAINS，再固定域名，再远程列表、TXT、最后日期派生候选；具体候选/选中域名没有实测值|同文件:12449、12481、12506|
|日期派生候选|`MD5(本地YYYY-MM-DD + 包内5个JP前缀常量).substring(9,19)+'.com'`|随机子域与日期派生域名用于连接发现，不是视频内容加密；这是构造逻辑，不证明这些域已注册/在线|同文件:12428、12497|
|图片与广告图片|`https://{imgDomain候选}{原路径+query+hash}`|GET 图片；两个配置接口返回 imgDomain 逗号列表；即便原图片为完整 URL，也替换主机；5秒超时/失败换候选；实际 CDN 主机未知|同文件:21460、21476、21518|
|统计脚本|`https://d.alicdn.com/alilog/mlog/aplus/203467608.js`|HTML 注入异步脚本，浏览器 GET；每次路由切换调用 aplus.sendPV；脚本本体不在附件，不能据此列举全部上报接口|H:10、16；F:index-B33oKSXv.js:21400|
|统计兼容重定向|`file://umini.shujupie.com/*` → `https://umini.shujupie.com/*`|主进程仅注册重定向规则；没有本次请求路径、方法或 payload 证据，不能当作已经发送的接口|S:main/index.js:221|
|本地媒体引擎|`http://127.0.0.1:{port}`，默认 port=5800|POST 控制 API 与 GET 播放流；端口从 tmp/JPEngine2.lock 读取；不是外部业务主机|F:index-B33oKSXv.js:15039；S:preload/index.js:43|
|影视媒体与更新包|详情返回的 source_list[].url / 短视频 url / 更新 mac_download_url|HTTP(S) 直链、非 HTTP 资源和 HTTPS 更新 URL 都是运行时数据；没有响应样本，不能列出实际 CDN、FTP、种子或安装包主机|F:Detail-D9nBaeLj.js:658；F:ShortDetail-Be5VM2Wq.js:343；F:index-B33oKSXv.js:21184|
|开发服务器|`http://localhost:5173`|仅 !app.isPackaged 分支，生产路径加载本地 dist/index.html；不能列为生产业务 API|S:main/index.js:235|

第三方库中的 `w3.org` XML/SVG 命名空间、GitHub/LICENSE、example.com、Vue 错误文档等字面量，没有第一方业务请求链，不计入业务域名。播放器库中的字幕脚本候选见逐项附录，也不冒充本次运行请求。

### C-DOMAINS

<!-- CODE_EVIDENCE:CB-1 -->
**调用链：** App → getSysInit → HTTP base resolver → p7 → candidate probe

```javascript
async function p7() {
    let e = c7(),
        t = await u0(e);
    if (t) return t;
    for (let n of p2)
        if (e = await d7(n), !!e && (localStorage.setItem(mf, JSON.stringify(e)), t = await u0(e), t)) return t;
    for (let n of o7)
        if (e = await f7(n), !!e && (localStorage.setItem(mf, JSON.stringify(e)), t = await u0(e), t)) return t;
    return e = h7(), t = await u0(e), t || null
}
```

**证明关系：** 证明候选选择顺序和缓存写入逻辑。
**证据边界：** 不证明候选当前存活或运行时选中了哪个域名。
**定位：** p7；E-1；formatted/dist/assets/index-B33oKSXv.js:12506；Bundle B-1；Path P-1。

## 请求封装、鉴权与加密

业务请求统一走 Axios 实例，普通相对 URL 拼接 `选中base + '/api'`。默认超时 10 秒、请求头 `platform: pc`（Mac 也沿用该值）、`content-type: application/x-www-form-urlencoded`。GET 参数放查询，POST 普通对象由 Axios 按该类型序列化；部分表单为 FormData。注册接口另有 15 秒超时与不重试配置。网络失败可重新发现域名并最多按 retryCount=3 递减重试；绝对 URL 不走这条域名切换重试。定位 F:index-B33oKSXv.js:12676–12835，完整方法保存在清单 JSON。

1. **初始化与签名**：`App.d → wo.getSysInit → GET /api/v2/sys/init` 配 noSignature=true，公共响应解包后读取 `secret`，交给 `ne.setSecret` 解锁等待 Promise。其他普通请求头为 `version=504`、`timestamp=floor(Date.now()/1000)`、`signature=MD5('504'+timestamp+secret)` 的十六进制字符串。计算没有拼入 URL、参数或请求体，不能称为“整包内容加密”。如果初始化失败，代码仅 catch/log，没有找到签名等待 Promise 的失败释放路径；后续签名请求可能一直等待，需运行验证。定位:12709、12797、21176。
2. **token 注入**：`U1(rawUrl)` 精确检查允许列表，或排除以 http 开头的绝对 URL。对需附加 token 的 `/v2` 路径，token 放请求头；其余 GET 写 params.token，POST 写 data.token 或 FormData。`/usersV2/*` 不含小写 `/v2`，因此走旧式 body/query 分支。匿名用户 token 可能为空，不能把“注入逻辑存在”解释为服务端一定要求登录。定位:7995、12706、12816。
3. **精确匹配细节**：允许列表中的 `/video/detailv2`、`/video/guessRecommend`，与实际含 `?id=` 的拼接字符串不相等；某些模板路径也未列在 allowlist。签名和 token 判断以代码实际字符串为准，不能按接口名称推断免鉴权。定位:7995、21858、21881。
4. **token 存储**：Pinia user store 将 userInfo JSON 保存至 localStorage，token 来源是 userInfo.token；昵称、头像、inviteCode/inviteImg 也有本地状态。不是在包内发现实际用户凭证，本报告不提取或公布凭证。定位:12572–12675。
5. **响应契约**：公共封装读取 `{code,msg,data,...other}`，code≠1 拒绝 `{code,msg}`；originalData=true 原样返回，否则返回 data；有额外顶层字段时挂到 data.other，data 为空时返回其余字段。HTTP 401 映射“请登陆”、500 映射服务端错误；这些是客户端映射，不是服务端实测状态。定位:12719–12756。
6. **加密边界**：CryptoJS 中确有 AES/DES/TripleDES 等通用算法实现，但本任务追踪到的第一方业务调用是 MD5 签名与日期候选计算；未找到这些业务请求的应用层 AES 加密/解密调用。播放器捆绑 HLS AES 解密库，仅证明支持加密 HLS 的库能力，不能证明实际影片使用该加密，更不能推断 DRM 或许可证服务。HTTPS 传输与应用层加密分开记录。
7. **传输配置**：主进程设置 disable-web-security，主窗口 sandbox=false；未在本次第一方 JavaScript 路径发现自定义证书 pin 或 TLS 验证覆盖。不能据此推断 Electron/系统验证已关闭，也不能覆盖未提供的 JPEngine2。IP 候选及 loopback 明确为 HTTP，其余固定 API 候选为 HTTPS。定位 S:main/index.js:20、145。

### C-AUTH

<!-- CODE_EVIDENCE:CB-2 -->
**调用链：** App.getSysInit → setSecret → page API → request interceptor → Axios

```javascript
                const n = Uo();
                t.method == "get" ? t.params.token = n.token : t.method == "post" && (t.data instanceof FormData ? t.data.append("token", n.token) : t.data.token = n.token)
            }
            if (!t.options.noSignature) {
                const n = await un(this, qo),
                    i = Math.floor(new Date().getTime() / 1e3),
                    o = "504",
                    a = t7.MD5(o + i + n).toString();
                t.headers.version = o, t.headers.timestamp = i, t.headers.signature = a
            }
            return t
```

**证明关系：** 证明 token 放置分支、MD5 输入与签名请求头。
**证据边界：** 不证明服务端鉴权有效性，secret 的实际值和完整响应未知。
**定位：** ys.request interceptor；E-2；formatted/dist/assets/index-B33oKSXv.js:12706；Bundle B-2；Path P-2。

## 核心网络接口清单

下表所有相对路径均须前加 `selected_base/api`。全部状态为“静态确认，动态未验证”。“响应”是代码读取的最小消费结构，不是完整 schema。完整 **130 个业务请求封装**已提供 `network_interfaces.md`、`.json`、`.csv`：99 个有静态调用点，31 个仅封装；逐项保留 HTTP 方法、原始路径表达式、查询/请求体、特殊配置、方法体与调用点。附加网络通道另见 `network_auxiliary.json`。

|用途|HTTP 方法与路径|主要参数|客户端消费结构|F:index-B33oKSXv.js|
|---|---|---|---|---|
|签名初始化|GET `/v2/sys/init`|noSignature=true|data.secret|15207；调用21176|
|应用配置|GET `/v2/settings/appAuthConfig`|无；域名探活用绝对 URL 且免签名|配置对象，客户端网站读取 er；完整结构未知|15204；15175|
|首页分类|GET `/v2/settings/homeCategory`|无|data:[{id,name,…}]|21676|
|分类子标签/模块|GET `/customTags/list`、`/pc_dyTag/list`、`/dyTag/hand_data`|category_id|子类数组；模块含 id/template/title/jump_address；hand_data 按模块 id 索引|21679–21708|
|影视模块列表|GET `/pc_dyTag/tpl{template}_list`|id,page,count=8（首页）|影视卡片数组；空数组/不足count结束|21693|
|轮播|GET `/slide/list`|pos_id=当前分类id|轮播数组；客户端读取图片、跳转地址|21709|
|搜索推荐/搜索|GET `/search/recommend`；GET `/v2/search/videoV2`|搜索 key,category_id,page|搜索 originalData:{code,msg,data:[影片],total,…}；影片读取 id/type/title/actors/years/res_categories/top_category/tvimg/description|21716、21719；消费 Search:196|
|筛选项|GET `/crumb/filterOptions`|fcate_pid，可未传|data:[{key,data:[{id,name,…}]}]|21870|
|筛选影视|GET `/crumb/list` 或 `/crumb/shortList`|路由/筛选项动态键及page；fcate_pid=67走短视频|卡片数组；读取 id/title/path 或 cover_image|21911|
|长视频详情/相关推荐|GET `/video/detailv2?id={id}`；GET `/video/guessRecommend?id={id}&page={page}`|嵌入查询字符串|详情含 title/score/category/directors/actors/types/area/year/description/thumbnail/cate_id/source_list_source；推荐数组|21855、21877|
|评论|GET `/v2/comment/list`；POST `/v2/comment/add`|列表 video_id,weight,sort=changed,page,pageSize=15；提交 video_id,weight,content,reply_comment_id|评论列表数据及附加计数；完整 schema 未知|13193、13207|
|短视频列表/详情/合集|GET `/play`、`/detail`、`/narratecollection`|type,page,count=10,order=2；vid；svid|列表与短详情对象，最终播放读取 url；合集数据|21637、21594、21665|
|上映表|GET `/discover/list`、`/discover/before`|type,year,page,pageSize；当前页20，早期页6|data[0].sub[]，每项 sub_name/sub[]|21860、21865|
|专题|GET `/special/list`、`/special/detail`|page；id|专题数组/详情，收藏相关接口另列完整清单|21820、21827|
|周榜|GET `/weekRank/options`、`/weekRank/list`|category_id|分类选项{name,category_id}；影视数组含id,title,path/cover_image,types/categories,description|22068、22071|
|求片|GET `/ask/list`；POST `/ask/user_apply`；POST `/ask/thumb`|page；title,category_id,desc；id|求片列表/提交结果；完整 schema 未知|22081、22091、22100|
|收藏状态/添加|GET `/v2/nUser/getCollectSingle`；POST `/nUser/collectVideo`|type,vid；id,type（影片1/短片2）|状态值；变更结果不作为运行成功证据|22114、13219|
|收藏列表/批量取消|GET `/nUser/getCollect`；POST `/nUser/cancelCollectVideoBatch`|page,pageSize（个人中心15）；ids=逗号串|originalData:{data:[…],totalPage,…}|21753、21777|
|观看历史列表/删除|GET `/v2/view/list`；POST `/usersV2/deleteViewCollection`|page,pageSize=15；collections=逗号串|originalData.data[]，含collection/video_id/type|21784、21806|
|播放记录上报|POST `/usersV2/viewVideo`|type,video_id,video_name,source_id,source_config_name,weight_alias,last_duration,total_duration,category_id,path|返回值不直接渲染；服务端结果未知|22033|
|下载记录|POST `/nUser/downloadVideo`|video_id,video_name,source_id,source_config_name,weight_alias,type=1|记录行为，不传输影视文件；仅下载弹窗内调用点，开启入口未确认|21883；Detail:157|
|广告配置与计数|GET `/v2/advertise/list`；POST `/v2/advertise/recordShow`、`/recordClick`|channel,client=3；ad_id,pos,client=3,channel|配置含info_flow/comment/user_center等；曝光/点击记录结果|12837–12876；AdImage:24、36|
|图片/广告资源域|GET `/v2/settings/resourceDomainConfig`、`/advertiseDomainConfig`|无|data.imgDomain=逗号分隔域名|15194、15216|
|版本查询|GET `/v2/settings/updateAd`|启动id=mac；手动检查未传id|versioncode,mac_download_url,pc_download_url,text|15197；21184|
|账号|POST `/nUser/accountLogin`、`/mailLogin`、`/phoneLogin`；注册走对应 `/v2/nUser/*Register`|account/password；mail/password；pre/phone/msg_code；具体表单见完整清单|成功结果写userInfo，客户端期望token、vip_level等；完整schema未知|12920–13046|
|反馈|POST `/feedback`|content,contact,type,client|公共成功/失败契约|13083|

详情媒体对象至少消费：`source_list_source:[{id,name,source_list:[{url,weight,source_name,time_data:{titles_duration,trailer_duration},…}]}]`；VIP 对象为 `vip_source_list_source` 但受关闭开关限制。选集下载还读取 source.video_id/video_name/source_id/source_config_name；这只证明客户端预期字段，不保证每个响应都包含或每种类型相同。

## 播放器与本地引擎

**链路一，HTTP(S) 直链播放**：分类/搜索卡片 → 长详情接口 → 来源与分集 → `url.startsWith('http')` 分支 → VideoPlayer → Video.js `src/load` → 浏览器媒体请求。附件捆绑 Video.js `8.22.0`、`@videojs/http-streaming 3.17.0`、m3u8-parser 与 MPD parser，支持 MP4/HLS/DASH 的库路径；不能仅凭库存在宣称实际影片采用 HLS/DASH。普通媒体没有业务 signature 注入；VIP 条件下 `R.Vhs.xhr.beforeRequest` 设置 token 请求头，仅证明 VHS 请求分支，不涵盖所有原生 HTML5 MP4 请求。定位 F:VideoPlayer-9YDDWVER.js:7708、15279、27562。

**链路二，非 HTTP 播放**：主进程启动包外引擎 → preload 读取临时目录 JPEngine2.lock → 本地端口 → POST create → 返回 loopback `/p2p/{base64url(resource)}` → 约2秒后以 `video/mp4` 交给 Video.js。资源编码为 UTF-8 Base64，移除 padding 并替换 `+ /` 为 `- _`，不是加密。详情代码对所有非 http 开头资源都进入引擎，不仅限 FTP；下载调度却只识别 `ftp://`。macOS 生产启动路径为 `path.dirname(process.execPath)` 下 `../JPEngine2`，ASAR 内未包含该二进制。定位 S:main/index.js:42–64；S:preload/index.js:43–51；F:index-B33oKSXv.js:7979、15039。

### C-PLAY

<!-- CODE_EVIDENCE:CB-4 -->
**调用链：** Detail → source_list.url → Tn.getPlayUrl → local engine → VideoPlayer

```javascript
                    if (!D.startsWith("http")) {
                        t = D, A.ready = !1, A.status = "资源获取中···";
                        try {
                            ge.getPlayUrl(D).then(async E => {
                                await new Promise(Se => setTimeout(Se, 2e3)), A.srcs = [{
                                    src: E,
                                    type: "video/mp4"
                                }], A.status = ""
                            }).catch(() => {
                                A.status = "资源获取失败"
                            }).finally(() => {
                                A.ready = !0
```

**证明关系：** 证明非 HTTP 分支取得本地播放 URL，并以 video/mp4 提供给播放器。
**证据边界：** 包外 JPEngine2 未提供，不能证明上游协议、节点、资源可播或媒体真实格式。
**定位：** Detail source watchEffect；E-4；formatted/dist/assets/Detail-D9nBaeLj.js:669；Bundle B-4；Path P-4。

本地控制均由 `fetch` 构造 **POST**，默认10秒 AbortController 超时；资源作为 URL 路径参数，参数不存在则不加资源段；未显式附带签名或 token。成功响应统一读文本，HTTP 非2xx抛错。以下不是动态观测到的流量。

|本地路径（主机均127.0.0.1:{port}）|方法|路径参数/请求体|响应消费及可达性|
|---|---|---|---|
|`/api/v1/create/{resource_b64url}`|POST|资源URL的编码；无业务body|文本；由非HTTP播放和下载调度调用|
|`/p2p/{resource_b64url}`|媒体GET预期|资源URL编码；Range是否使用需运行确认|媒体字节，应用声明video/mp4；不是已验证MIME或响应头|
|`/api/v1/setpath`|POST|body=下载目录原始字符串|文本；配置初始化调用，同时IPC创建目录|
|`/api/v1/pause/{resource_b64url}`|POST|无业务body|文本；队列控制实现，用户界面入口未确认|
|`/api/v1/resume/{resource_b64url}`|POST|无业务body|文本；队列控制实现，用户界面入口未确认|
|`/api/v1/cancel/{resource_b64url}`|POST|无业务body|文本；移除缓存或停止当前资源分支|
|`/api/v1/delete/{resource_b64url}`|POST|无业务body|文本；移除任务后调用；引擎是否删实际文件未知|
|`/api/v1/get_download_speed/{resource_b64url}`|POST|无业务body|文本转数值用于speed；单位由引擎决定、未验证|
|`/api/v1/get_size/{resource_b64url}`|POST|无业务body|大小文本或 ERR Not Found Task|
|`/api/v1/get_downloaded_size/{resource_b64url}`|POST|无业务body|已下载大小文本；计算进度百分比|
|`/api/v1/set_p2p_play_timeout`|POST|body=timeout的JSON序列化|仅找到封装，未找到调用点|
|`/api/v1/get_task_list`|POST|无业务body|仅找到封装，响应结构未知|

引擎内部的 TCP/UDP、FTP连接、P2P/P2SP 调度、服务发现、分片协议、上游域名、校验、加密和磁盘格式均超出本附件证据。不能把 JPEngine2 名称或 ftp URL 推导为已经分析了 Native 实现。

## 下载、缓存与本地状态

选集组件取 `videoDetail.source_list_source[0].source_list`，不是所有来源；要求登录且至少选择一集。`TR.download` 去重资源URL、写影视详情缓存及 DownlaodVideos（代码原拼写），只有 `ftp://` 被标记 type=1。每秒轮询下载大小、速度、已下载大小并计算 progress；并发默认2，MaxDownloadCount 可持久化。状态0待调度、1创建中、2下载中、3暂停、4完成、5失败。暂停/恢复/取消/删除均有实现，但没有常规界面开关或下载管理页面的可达证据。HTTP 资源被type=0排除在该FTP调度循环外，不能宣称这条队列支持HTTP下载。

详情内下载弹窗的 show 来自 VideoInfo 的 `l = _(!1)`；该作用域未找到令 l.value=true 的代码，只找到关闭赋值。顶栏“扫码下载移动端”不属于影视缓存。已有本地缓存通过 `?cache&sid&eid` 分支读取详情；同样不能证明用户能够从常规页面进入。定位 F:Detail-D9nBaeLj.js:100–165、355、518、574、695；F:index-B33oKSXv.js:20979–21102。

### C-DOWNLOAD

<!-- CODE_EVIDENCE:CB-5 -->
**调用链：** embedded downloadSelect.m (opening path unconfirmed) → TR.download → task scheduler

```javascript
            localStorage.setItem(`cache-video-datail-${w.id}`, JSON.stringify(w)), y = y.filter(A => !n.value.find(v => v.url == A.url)), y = y.map(A => (A.cateId = w.cate_id, A.cover ?? (A.cover = w.thumbnail), {
                speed: 0,
                progress: 0,
                status: 0,
                fileSize: 0,
                url: A.url,
                type: A.url.startsWith("ftp://") ? 1 : 0,
                videoInfo: A
            })), n.value.push(...y)
        }
        async function u(y) {
            const w = n.value.findIndex(A => A.url == y);
            if (w != -1) {
```

**证明关系：** 证明缓存元数据持久化、URL 去重及仅 FTP 分类为可调度下载类型。
**证据边界：** 选集弹窗没有发现开启入口；不能宣称本版本下载页面可用或下载已完成。
**定位：** TR.download；E-5；formatted/dist/assets/index-B33oKSXv.js:21039；Bundle B-5；Path P-5。

|存储位置或键|内容与用途|证据|
|---|---|---|
|localStorage API_DOMAINS / LAST_VALID_API_DOMAIN|候选列表与最近有效域名|F:index-B33oKSXv.js:12419|
|localStorage userInfo / inviteCode / inviteImg / ads|账号状态与广告缓存|同文件:12572、12890|
|localStorage search_history|搜索输入历史，清除不等于清除观看历史|F:Action-DoKrXy2x.js:214、266|
|localStorage source-episode-{vid}|sourceId与episodeId，用于详情选源/选集记忆|F:Detail-D9nBaeLj.js:711|
|localStorage cache-video-datail-{id}|完整详情对象缓存，datail为代码拼写；不是影片字节|F:index-B33oKSXv.js:21040|
|localStorage DownlaodVideos / MaxDownloadCount / DownloadPath|任务元数据、并发及下载目录；默认系统Downloads/JianPian|同文件:20979、21000、15136|
|localStorage volume / autoSkipIntroEnabled / autoSkipOutroEnabled|音量与跳片头片尾偏好|F:VideoPlayer-9YDDWVER.js:27483|
|electron-store|AutoRun、MinimizePosition、CloseStatus、VersionUpdate、VersionInfo|S:preload/store.js；F:SetUp-DPMSXjnW.js:84|
|临时目录 JPEngine2.lock|端口文本；2秒轮询，最多5次；默认5800|S:preload/index.js:43；F:index-B33oKSXv.js:15065|

localStorage 与 electron-store 的实际磁盘位置依赖完整 macOS 应用与 userData 配置，ASAR 不能证明本机绝对路径；没有导出用户目录或现存数据。媒体字节是否写入 DownloadPath、文件名及完成后的索引关系须由引擎/运行观察确认。

## 收藏与历史

长视频收藏通过用户接口切换，先用 getCollectSingle 查询状态。个人中心影片、专题、片单各有分页与批量删除；选中项ID拼成逗号串。观看历史列表是云端 `/v2/view/list`，删除按 collections，而本地 source-episode 只记选源/选集，不能当作完整观看历史。

VideoPlayer 的 timeupdate 更新本地时长变量；组件销毁时发送 `playEnd(last,total)`，详情登录分支才调用 `/usersV2/viewVideo`。不是每秒云端上报，也未在该长详情路径证明自动恢复历史进度。是否服务端保存、跨设备同步、刷新或异常退出丢记录均未动态验证。定位 F:VideoPlayer-9YDDWVER.js:27528、27626；F:Profile-Cor6JmxC.js:256、265。

### C-HISTORY

<!-- CODE_EVIDENCE:CB-6 -->
**调用链：** VideoPlayer unmount playEnd → Detail.U → Detail.a → tg.addPlayRecord

```javascript
            }
            async function a(s, i) {
                var c, f, g, D, A;
                if (x.isLogin) try {
                    await Z.addPlayRecord(1, m, (c = r.value) == null ? void 0 : c.title, w.value, ((f = J.value) == null ? void 0 : f.name) ?? "", ((g = Y.value) == null ? void 0 : g.source_name) ?? "", s, i, (D = r.value) == null ? void 0 : D.cate_id, (A = r.value) == null ? void 0 : A.thumbnail)
                } catch (E) {
                    console.log(E.msg)
                }
            }

            function U(s, i) {
                a(s, i)
            }
```

**证明关系：** 证明登录条件下提交影视来源及播放时长到服务端历史接口。
**证据边界：** 不证明请求实际发送、服务端保存成功或跨设备同步结果。
**定位：** Detail.a/U；E-6；formatted/dist/assets/Detail-D9nBaeLj.js:724；Bundle B-6；Path P-6。

## 设置与更新

设置保存到 electron-store；开机自启通过 app.setLoginItemSettings 落地，关闭窗口读取 CloseStatus 选择隐藏或退出。MinimizePosition 有配置字段，但不能仅凭保存字段宣称 macOS 的任务栏/托盘行为都已生效。更新模式0为打开更新窗后立即下载，模式1为提醒后点击下载；这里是本附件的自定义实现，没有证据将它归为 electron-updater。

启动自动检查：`getNativeParams.system=='Mac' → getVersion('mac') → mac_download_url → VersionInfo → Update → ElectronAPI.download → main downloadFile → https.get → 文件 → install → shell.openPath → app.quit`。

手动检查：CheckUpdate 调用 getVersion() 不传 id，解构 pc_download_url 并保存，因此与启动Mac分支不同。响应由服务器决定，不能断言一定下错安装包；但这段静态平台选择差异已确认。软件包 GET 使用固定 Windows Chrome User-Agent，即使客户端为Mac；未附业务token/signature。downloadFile 未找到状态码成功判断、重定向跟随或下载包hash/签名校验代码，只有内容流写盘与完成回调；未提供完整应用签名及安装包，不能扩展为系统安全结论。定位 S:main/utils.js:11–56；S:main/event-handlers.js:55–98。

### C-UPDATE

<!-- CODE_EVIDENCE:CB-7 -->
**调用链：** manual check → wo.getVersion(undefined) → pc_download_url → VersionInfo → Update.download

```javascript
                    const {
                        versioncode: e,
                        pc_download_url: t,
                        text: f
                    } = await g.getVersion();
                    y.setStoreValue("VersionInfo", {
                        version: e,
                        url: t,
                        desc: f
                    }), _.value = e, a.value = V(e, o.version)
                } catch (e) {
                    console.log(e)
                } finally {
                    c.value = !1
```

**证明关系：** 证明手动检查未传 mac 平台 id，并把 PC URL 写入更新信息。
**证据边界：** 服务端可能调整响应；没有 macOS 运行证据，不宣称必然安装错误包。
**定位：** CheckUpdate mounted handler；E-7；formatted/dist/assets/CheckUpdate-DSfI3V6P.js:54；Bundle B-7；Path P-7。

## 交付与证据索引

- `jianpian_report.md` / `.html`：本报告；`network_interfaces.md` / `.json` / `.csv`：130项业务请求逐项清单，含完整封装方法与静态调用位置；`network_auxiliary.json`：本地引擎、域名分发、统计、图片及更新等补充网络通道。
- `asar_inventory.json`：786项原始资产路径、字节大小、偏移及SHA-256；`source_verification.json`：56个原始JS与可读副本的token一致性证明；`code_evidence.md`：本报告7个关键代码块；`quality_status.json`：质量检查与冻结结果。
- `extracted/`：原样解包文件；`formatted/`：仅排版的可读副本；没有改写目标代码。无需通过网页介绍或同名应用补齐缺失实现。
- 外部缺口：JPEngine2 原生实现、macOS真实请求、所选域名、服务端完整响应、实际媒体协议/鉴权/加密、缓存落盘和安装结果均未验证。静态报告可独立阅读，但这些部分不具备运行态结论。
