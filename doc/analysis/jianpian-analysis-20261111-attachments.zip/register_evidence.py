import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
project = root.parents[1]
runner = project / 'tools/_run.sh'

def state(command, *args):
    safe_args = [str(arg).replace(';', '；').replace(' -> ', ' → ') for arg in args]
    result = subprocess.run(['bash', str(runner), 'analysis_state', command, str(root), *safe_args],
                            capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr + result.stdout)

state('artifact', '--id', 'A-ASAR', '--path', root / 'input/app.asar', '--type', 'electron_asar', '--status', 'completed')
state('artifact', '--id', 'A-INVENTORY', '--path', root / 'asar_inventory.json', '--type', 'recursive_archive_inventory', '--status', 'completed', '--parent-id', 'A-ASAR')
for index, item in enumerate(json.loads((root / 'asar_inventory.json').read_text())):
    state('artifact', '--id', f'A-FILE-{index:03}', '--path', root / 'extracted' / item['path'],
          '--type', Path(item['path']).suffix.lstrip('.') or 'resource', '--parent-id', 'A-ASAR',
          '--status', 'completed' if not item['path'].startswith('node_modules/') else 'not_applicable',
          '--notes', 'Extracted unchanged; third-party dependencies excluded from first-party capability attribution.' if item['path'].startswith('node_modules/') else 'Extracted unchanged.')

main = 'formatted/dist/assets/index-B33oKSXv.js'
specs = [
    ('C-DOMAINS', '域名发现按缓存、固定域名、远程列表、DNS TXT、日期派生候选依次探活。', main, 12506, 12515,
     'p7', 'App -> getSysInit -> HTTP base resolver -> p7 -> candidate probe', 'E3',
     '证明候选选择顺序和缓存写入逻辑。', '不证明候选当前存活或运行时选中了哪个域名。'),
    ('C-AUTH', '业务 HTTP 封装使用服务器 secret 和版本时间戳 MD5 签名，并按 URL 条件附加 token。', main, 12706, 12716,
     'ys.request interceptor', 'App.getSysInit -> setSecret -> page API -> request interceptor -> Axios', 'E3',
     '证明 token 放置分支、MD5 输入与签名请求头。', '不证明服务端鉴权有效性，secret 的实际值和完整响应未知。'),
    ('C-PAGES', '主页面具有实际分类搜索详情调用链，功能依据本附件的路由与组件确认。', 'formatted/dist/assets/Search-Cfs0L6Gc.js', 193, 204,
     'Search.d', 'Home -> Search route -> Search.d -> tg.search -> Axios', 'E3',
     '证明搜索以分类、关键词和页码调用业务接口并消费结果。', '不证明接口当前可用或界面运行结果，搜索响应为客户端消费契约。'),
    ('C-PLAY', '长视频详情将非 HTTP 资源交给本地引擎转换为 MP4 播放地址，HTTP 地址直接交给播放器。', 'formatted/dist/assets/Detail-D9nBaeLj.js', 669, 680,
     'Detail source watchEffect', 'Detail -> source_list.url -> Tn.getPlayUrl -> local engine -> VideoPlayer', 'E3',
     '证明非 HTTP 分支取得本地播放 URL，并以 video/mp4 提供给播放器。', '包外 JPEngine2 未提供，不能证明上游协议、节点、资源可播或媒体真实格式。'),
    ('C-DOWNLOAD', '下载选集、FTP 任务调度和进度实现存在，但正常界面开启下载弹窗的路径未找到。', main, 21039, 21051,
     'TR.download', 'embedded downloadSelect.m (opening path unconfirmed) -> TR.download -> task scheduler', 'E2',
     '证明缓存元数据持久化、URL 去重及仅 FTP 分类为可调度下载类型。', '选集弹窗没有发现开启入口；不能宣称本版本下载页面可用或下载已完成。'),
    ('C-HISTORY', '收藏和观看历史通过服务端接口管理，观看进度在播放器退出事件上报。', 'formatted/dist/assets/Detail-D9nBaeLj.js', 724, 736,
     'Detail.a/U', 'VideoPlayer unmount playEnd -> Detail.U -> Detail.a -> tg.addPlayRecord', 'E3',
     '证明登录条件下提交影视来源及播放时长到服务端历史接口。', '不证明请求实际发送、服务端保存成功或跨设备同步结果。'),
    ('C-UPDATE', '启动自动更新按平台取 URL，但手动检查更新读取 PC 字段，macOS 路径存在静态不一致。', 'formatted/dist/assets/CheckUpdate-DSfI3V6P.js', 54, 67,
     'CheckUpdate mounted handler', 'manual check -> wo.getVersion(undefined) -> pc_download_url -> VersionInfo -> Update.download', 'E3',
     '证明手动检查未传 mac 平台 id，并把 PC URL 写入更新信息。', '服务端可能调整响应；没有 macOS 运行证据，不宣称必然安装错误包。')
]
blocks = []
for number, (cid, claim, file, start, end, symbol, chain, level, proves, boundary) in enumerate(specs, 1):
    eid, lid, bid, path_id, cbid = f'E-{number}', f'L-{number}', f'B-{number}', f'P-{number}', f'CB-{number}'
    state('lead', '--id', lid, '--summary', claim, '--priority', 'high', '--source-kind', 'script_implementation',
          '--source-ref', f'{file}:{start}', '--status', 'proven', '--reason', 'Implementation and callers reviewed; boundaries retained.')
    state('evidence', '--id', eid, '--level', 'E2', '--kind', 'script_implementation', '--summary', claim,
          '--file', root / file, '--line', start, '--tool', 'static_source_review', '--artifact-id', 'A-ASAR')
    state('edge', '--id', path_id, '--source', chain.split(' -> ')[0], '--relation', 'conditional_script_call_chain',
          '--target', chain, '--evidence', eid)
    state('claim', '--id', cid, '--text', claim, '--importance', 'high', '--level', level, '--required-level', level,
          '--domain', 'config', '--status', 'proven', '--evidence', eid, '--path-id', path_id,
          '--scope', 'Actual app.asar SHA256 c8b0d5c2fe0843da97d2a763d329cc4bae079e71456450e3f6eb531236d191d5',
          '--confidence', 'high', '--provenance', 'first_party', '--conditions', 'Static branch conditions and feature flags apply.',
          '--counter-evidence', boundary, '--coverage', 'First-party JavaScript inspected; external engine and runtime absent.',
          '--dynamic-gap', 'Linux analysis host; macOS app shell and JPEngine2 absent.', '--no-dynamic-needed', '--dynamic-priority', 'none')
    state('code-evidence', '--id', cbid, '--claim-id', cid, '--evidence-id', eid, '--language', 'javascript',
          '--symbol', symbol, '--source-file', root / file, '--line-start', start, '--line-end', end,
          '--call-chain', chain, '--key-logic', proves, '--proves', proves, '--boundary', boundary,
          '--redaction-status', 'not_required')
    state('evidence-bundle', '--id', bid, '--claim-id', cid, '--finding', claim, '--leads', lid,
          '--static-evidence', eid, '--path-id', path_id, '--code-evidence', cbid, '--allowed-conclusion', claim,
          '--forbidden-expansion', boundary, '--report-summary', claim, '--technical-refs', f'{file}:{start}')
    chain = chain.replace(' -> ', ' → ')
    excerpt = '\n'.join((root / file).read_text().splitlines()[start-1:end])
    blocks.append(f'### {cid}\n\n<!-- CODE_EVIDENCE:{cbid} -->\n**调用链：** {chain}\n\n```javascript\n{excerpt}\n```\n\n**证明关系：** {proves}\n**证据边界：** {boundary}\n**定位：** {symbol}；{eid}；{file}:{start}；Bundle {bid}；Path {path_id}。\n')
state('dynamic-plan', '--mode', 'static-only', '--reason', 'Host Linux; no macOS target runtime or external JPEngine2; no application request was dynamically verified.')
for dimension in ['pages', 'business_http', 'authentication', 'playback_js', 'download_js', 'favorites_history', 'settings_updates']:
    state('coverage', '--dimension', dimension, '--status', 'completed', '--notes', 'Static JavaScript scope; no runtime claims.')
state('coverage', '--dimension', 'native_engine_and_dynamic_requests', '--status', 'incomplete', '--notes', 'External JPEngine2 and macOS runtime not supplied.')
state('task', '--id', 'static-analysis', '--kind', 'static', '--status', 'completed', '--detail', 'ASAR extraction and first-party source tracing completed.')
state('outcome', '--status', 'limited', '--detail', 'External native engine and runtime missing; meaningful static report produced.')
(root / 'code_evidence.md').write_text('\n'.join(blocks))
print(f'Registered {len(specs)} bounded claims and 786 extracted assets.')
