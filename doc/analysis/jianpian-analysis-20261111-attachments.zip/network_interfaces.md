# 荐片 macOS 5.0.4 · 网络接口逐项清单

## 结论

本清单从实际附件 JavaScript AST 提取 130 个业务请求封装；仅描述静态代码，未发送这些请求。

|事项|结论|
|---|---|
|目标|附件 app.asar，package.json version=5.0.4|
|动态请求|0 项完成运行验证；所有响应均为客户端消费契约，不是实测响应|
|路径规则|相对路径前加 selected_base + /api；模板和查询拼接保留原表达式|

## 阅读约定

caller_found 只表示存在静态调用点，不保证每个开关或分支均可运行；wrapper_only 不认定页面已启用。参数右侧为封装函数的局部变量，请结合原方法签名和调用点查看实际来源。

GET 的 params 为查询参数，POST 的 data 通常按 application/x-www-form-urlencoded 序列化。正常签名头为 version=504、timestamp=秒级时间、signature=MD5("504"+timestamp+secret)。secret 来自 /api/v2/sys/init；该初始化及域名探活不签名。token 是否附加由 U1 对原始 URL 字符串精确比较决定，不能以“公开接口”自行推断。

响应封装要求 code=1，否则拒绝 {code,msg}；originalData=true 返回原对象，其他通常返回 data。没有服务端样本，所有完整 schema、可选字段、实际值及鉴权效果均未验证。下列调用点包含真实源文件行号；formatted 是只改变排版的派生副本，原压缩文件保留在 extracted，行号通常为 1。

## 影视与发现

### API-071 tg.getHomeCategorys

- 请求：`GET` `"/v2/settings/homeCategory"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21677`。
- 调用点：`formatted/dist/assets/Home-HYqkCKsk.js:75`；`formatted/dist/assets/Search-Cfs0L6Gc.js:186`；`formatted/dist/assets/Action-DoKrXy2x.js:225`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-072 tg.getSubCategorys

- 请求：`GET` `"/customTags/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21680`。
- 查询：
```javascript
{
                category_id: t
            }
```
- 调用点：`formatted/dist/assets/Category-aMbhBLHJ.js:313`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-073 tg.getHomeTags

- 请求：`GET` `"/pc_dyTag/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21687`。
- 查询：
```javascript
{
                category_id: t
            }
```
- 调用点：`formatted/dist/assets/Category-aMbhBLHJ.js:325`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-074 tg.getTagVideos

- 请求：`GET` ``/pc_dyTag/tpl${t}_list``。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21694`。
- 查询：
```javascript
{
                id: n,
                page: o,
                count: i
            }
```
- 调用点：`formatted/dist/assets/Category-aMbhBLHJ.js:341`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-075 tg.getHomeHandData

- 请求：`GET` `"/dyTag/hand_data"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21703`。
- 查询：
```javascript
{
                category_id: t
            }
```
- 调用点：`formatted/dist/assets/Category-aMbhBLHJ.js:321`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-076 tg.getSwipes

- 请求：`GET` `"/slide/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21710`。
- 查询：
```javascript
{
                pos_id: t
            }
```
- 调用点：`formatted/dist/assets/Category-aMbhBLHJ.js:286`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-077 tg.searchRecommend

- 请求：`GET` `"/search/recommend"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21717`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-078 tg.search

- 请求：`GET` `"/v2/search/videoV2"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21724`。
- 查询：
```javascript
{
                key: t,
                category_id: n,
                page: i
            }
```
- 特殊配置：
```javascript
{
                options: {
                    originalData: !0
                }
            }
```
- 调用点：`formatted/dist/assets/Search-Cfs0L6Gc.js:197`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-079 tg.searchCategory

- 请求：`GET` `"/v2/settings/topCategory"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21738`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-080 tg.getRecommendVideo

- 请求：`GET` `"/search/searchList?category_id=" + t + "&page=" + n`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21744`。
- 调用点：`formatted/dist/assets/Action-DoKrXy2x.js:142`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-081 tg.collectVideo

- 请求：`POST` `"/nUser/collectVideo"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21747`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-082 tg.getCollectVideos

- 请求：`GET` `"/nUser/getCollect"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21757`。
- 查询：
```javascript
{
                page: t,
                pageSize: n
            }
```
- 特殊配置：
```javascript
{
                options: {
                    originalData: !0
                }
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:690`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-083 tg.cancelCollect

- 请求：`POST` `"/nUser/cancelVideoCollect"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21770`。
- 请求体：
```javascript
{
                id: t,
                tag: 1
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-084 tg.cancelCollectVideoBatch

- 请求：`POST` `"/nUser/cancelCollectVideoBatch"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21778`。
- 请求体：
```javascript
{
                ids: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:657`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-085 tg.getPlayHistory

- 请求：`GET` `"/v2/view/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21785`。
- 查询：
```javascript
{
                page: t,
                pageSize: n
            }
```
- 特殊配置：
```javascript
{
                options: {
                    originalData: !0
                }
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:256`；`formatted/dist/assets/Action-DoKrXy2x.js:1217`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-086 tg.getPlayDetailHistory

- 请求：`GET` `"/usersV2/getView"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21798`。
- 查询：
```javascript
{
                collection: t,
                page: n,
                pageSize: i
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-087 tg.deletePlayHistory

- 请求：`POST` `"/usersV2/deleteViewCollection"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21807`。
- 请求体：
```javascript
{
                collections: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:265`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-088 tg.deleteView

- 请求：`POST` `"/usersV2/deleteView"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21814`。
- 请求体：
```javascript
{
                ids: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-089 tg.getSpecialList

- 请求：`GET` `"/special/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21821`。
- 查询：
```javascript
{
                page: t
            }
```
- 调用点：`formatted/dist/assets/Special-DtYGTdvn.js:43`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-090 tg.getSpecialDetail

- 请求：`GET` `"/special/detail"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21828`。
- 查询：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/SpecialDetail-D8YInbxV.js:74`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-091 tg.checkCollectSpecial

- 请求：`POST` `"/nUser/checkCollectSpecial"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21835`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/SpecialDetail-D8YInbxV.js:97`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-092 tg.collectSpecial

- 请求：`POST` `"/nUser/collectSpecial"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21842`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/SpecialDetail-D8YInbxV.js:107`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-093 tg.cancelSpecialCollect

- 请求：`POST` `"/nUser/cancelSpecialCollect"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21849`。
- 请求体：
```javascript
{
                ids: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:660`；`formatted/dist/assets/SpecialDetail-D8YInbxV.js:116`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-094 tg.getVideoDetail

- 请求：`GET` `"/video/detailv2?id=" + t`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21858`。
- 调用点：`formatted/dist/assets/Detail-D9nBaeLj.js:577`；`formatted/dist/assets/index-B33oKSXv.js:22250`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-095 tg.getDiscoverList

- 请求：`GET` `"/discover/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21861`。
- 查询：
```javascript
t
```
- 调用点：`formatted/dist/assets/Release-Bh6kA0Ho.js:44`；`formatted/dist/assets/HistoryRelease-DWD5fN7t.js:64`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-096 tg.getDiscoverBeforeList

- 请求：`GET` `"/discover/before"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21866`。
- 查询：
```javascript
t
```
- 调用点：`formatted/dist/assets/HistoryRelease-DWD5fN7t.js:81`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-097 tg.getFilterOptions

- 请求：`GET` `"/crumb/filterOptions"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21871`。
- 查询：
```javascript
{
                fcate_pid: t
            }
```
- 调用点：`formatted/dist/assets/HistoryRelease-DWD5fN7t.js:100`；`formatted/dist/assets/CategoryFilter-lllrC5Dm.js:135`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-098 tg.getVideoLike

- 请求：`GET` `"/video/guessRecommend?id=" + t + "&page=" + n`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21881`。
- 调用点：`formatted/dist/assets/Detail-D9nBaeLj.js:393`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-099 tg.recordDownload

- 请求：`POST` `"/nUser/downloadVideo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21891`。
- 请求体：
```javascript
{
                video_id: t,
                video_name: n,
                source_id: i,
                source_config_name: o,
                weight_alias: a,
                type: u
            }
```
- 调用点：`formatted/dist/assets/Detail-D9nBaeLj.js:157`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-100 tg.deleteDownload

- 请求：`POST` `"/nUser/deleteDownload"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21903`。
- 请求体：
```javascript
{
                url: n,
                id: t,
                tag: i
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-101 tg.getAllVideos

- 请求：`GET` `t.fcate_pid != "67" ? "/crumb/list" : "/crumb/shortList"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21914`。
- 查询：
```javascript
t
```
- 调用点：`formatted/dist/assets/CategoryFilter-lllrC5Dm.js:147`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-102 tg.addMovieLog

- 请求：`POST` `"/watch/addMovieLog"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21920`。
- 请求体：
```javascript
{
                vid: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-103 tg.getEmployList

- 请求：`GET` `"/watch/getMovieLog"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21927`。
- 查询：
```javascript
{
                page: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-104 tg.postShareMovie

- 请求：`POST` `"/share/movie"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21934`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/VideoPlayer-9YDDWVER.js:27290`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-105 tg.creatWatch

- 请求：`POST` `"/watch/create"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21941`。
- 请求体：
```javascript
t
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-106 tg.specialCollectRecord

- 请求：`GET` `"/nUser/getSpecial"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21946`。
- 查询：
```javascript
{
                page: t,
                pageSize: n
            }
```
- 特殊配置：
```javascript
{
                options: {
                    originalData: !0
                }
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:696`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-107 tg.watchCollectRecord

- 请求：`GET` `"/watch/getWatchCollectList"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21959`。
- 查询：
```javascript
{
                page: t,
                pageSize: n
            }
```
- 特殊配置：
```javascript
{
                options: {
                    originalData: !0
                }
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:699`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-108 tg.searchWatchList

- 请求：`GET` `"/watch/getList"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21972`。
- 查询：
```javascript
{
                tag: t,
                pageSize: n,
                page: i
            }
```
- 调用点：`formatted/dist/assets/MovieViewList-CH2ek02P.js:55`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-109 tg.watchListDetail

- 请求：`POST` `"/watch/getDetail"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21981`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/MovieViewListDetail-CWLe9dDb.js:77`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-110 tg.checkCollectWatch

- 请求：`POST` `"/watch/checkWatchCollect"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21988`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/MovieViewListDetail-CWLe9dDb.js:97`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-111 tg.collectWatch

- 请求：`POST` `"/watch/setWatchCollect"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21995`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/MovieViewListDetail-CWLe9dDb.js:107`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-112 tg.cancelCollectWatch

- 请求：`POST` `"/watch/cancelWatchCollect"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22002`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/MovieViewListDetail-CWLe9dDb.js:112`；`formatted/dist/assets/Profile-Cor6JmxC.js:663`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-113 tg.userWatchList

- 请求：`GET` `"/watch/getWatchList"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22009`。
- 查询：
```javascript
{
                page: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-114 tg.deleteUserWatch

- 请求：`POST` `"/watch/deleteWatch"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22016`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-115 tg.editWatch

- 请求：`POST` `"/watch/editWatch"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22023`。
- 请求体：
```javascript
t
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-116 tg.getVideoSubList

- 请求：`GET` ``/dyTag/tpl${n}_subchannel?id=` + t + "&page=" + i`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22028`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-117 tg.getVideoList

- 请求：`GET` ``/dyTag/tpl${n}_data?id=` + t + "&page=" + i`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22031`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-118 tg.addPlayRecord

- 请求：`POST` `"/usersV2/viewVideo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22034`。
- 请求体：
```javascript
{
                type: t,
                video_id: n,
                video_name: i,
                source_id: o,
                source_config_name: a,
                weight_alias: u,
                last_duration: c,
                total_duration: f,
                category_id: d,
                path: h
            }
```
- 调用点：`formatted/dist/assets/ShortDetail-Be5VM2Wq.js:392`；`formatted/dist/assets/Detail-D9nBaeLj.js:728`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-119 tg.uploadWatch

- 请求：`POST` `"/watch/upload"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22050`。
- 请求体：
```javascript
t
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-120 tg.shareSpecial

- 请求：`POST` `"/share/special"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22055`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-121 tg.shareMovieWatch

- 请求：`POST` `"/share/movieWatch"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22062`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-122 tg.getWeekRankOptions

- 请求：`GET` `"/weekRank/options"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22069`。
- 调用点：`formatted/dist/assets/Ranking-DPccmXn-.js:92`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-123 tg.getWeekRankList

- 请求：`GET` `"/weekRank/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22072`。
- 查询：
```javascript
{
                category_id: t
            }
```
- 调用点：`formatted/dist/assets/Ranking-DPccmXn-.js:100`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-124 tg.watchTags

- 请求：`GET` `"/watch/tags"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22079`。
- 调用点：`formatted/dist/assets/MovieViewList-CH2ek02P.js:44`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-125 tg.getAskList

- 请求：`GET` `"/ask/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22082`。
- 查询：
```javascript
{
                page: t
            }
```
- 调用点：`formatted/dist/assets/RequestRanking-C1EjNOvp.js:79`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-126 tg.getFenlei

- 请求：`GET` `"/term/fenlei"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22089`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:13743`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-127 tg.createAskUserApply

- 请求：`POST` `"/ask/user_apply"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22092`。
- 请求体：
```javascript
{
                title: t,
                category_id: n,
                desc: i
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:13756`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-128 tg.askThumb

- 请求：`POST` `"/ask/thumb"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22101`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/RequestRanking-C1EjNOvp.js:89`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-129 tg.getCommentFavor

- 请求：`GET` `"/v2/comment/favor"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22108`。
- 查询：
```javascript
{
                comment_id: t
            }
```
- 调用点：`formatted/dist/assets/VideoPlayer-9YDDWVER.js:179`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-130 tg.getCollectSingle

- 请求：`GET` `"/v2/nUser/getCollectSingle"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:22115`。
- 查询：
```javascript
{
                type: t,
                vid: n
            }
```
- 调用点：`formatted/dist/assets/ShortDetail-Be5VM2Wq.js:173`；`formatted/dist/assets/Detail-D9nBaeLj.js:365`；`formatted/dist/assets/index-B33oKSXv.js:22265`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

## 短视频

### API-062 YR.getVideoDetail

- 请求：`GET` `"/detail"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21595`。
- 查询：
```javascript
{
                vid: t
            }
```
- 调用点：`formatted/dist/assets/ShortDetail-Be5VM2Wq.js:319`；`formatted/dist/assets/ShortVideo-CDQMB1dB.js:690`；`formatted/dist/assets/index-B33oKSXv.js:22244`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-063 YR.getGuessLinkVideos

- 请求：`GET` `"/guesslike"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21607`。
- 查询：
```javascript
{
                type: t,
                order: n,
                page: i,
                count: o
            }
```
- 调用点：`formatted/dist/assets/ShortDetail-Be5VM2Wq.js:178`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-064 YR.collectVideo

- 请求：`GET` `"/favorite"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21617`。
- 查询：
```javascript
{
                svid: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-065 YR.cancelCollectVideo

- 请求：`GET` `"/unfavorite"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21624`。
- 查询：
```javascript
{
                svid: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-066 YR.postShareShort

- 请求：`POST` `"/share/short"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21631`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/ShortVideo-CDQMB1dB.js:477`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-067 YR.getShortList

- 请求：`GET` `"/play"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21638`。
- 查询：
```javascript
{
                type: t,
                page: n,
                count: i,
                order: o
            }
```
- 调用点：`formatted/dist/assets/ShortVideo-CDQMB1dB.js:665`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-068 YR.like

- 请求：`GET` `"/like"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21648`。
- 查询：
```javascript
{
                svid: t
            }
```
- 调用点：`formatted/dist/assets/ShortVideo-CDQMB1dB.js:489`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-069 YR.addFavourite

- 请求：`POST` `"/nUser/collectVideo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21658`。
- 请求体：
```javascript
{
                id: t,
                type: n
            }
```
- 调用点：`formatted/dist/assets/ShortVideo-CDQMB1dB.js:500`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-070 YR.getCollection

- 请求：`GET` `"/narratecollection"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:21668`。
- 查询：
```javascript
{
                svid: t
            }
```
- 调用点：`formatted/dist/assets/ShortVideo-CDQMB1dB.js:251`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

## 账号与互动

### API-004 nn.registerPhone

- 请求：`POST` `"/v2/nUser/phoneRegister"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12921`。
- 请求体：
```javascript
{
                pre: t,
                phone: n,
                msg_code: i
            }
```
- 特殊配置：
```javascript
{
                timeout: 15e3,
                options: {
                    retryCount: 0
                }
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14212`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-005 nn.phoneLogin

- 请求：`POST` `"/nUser/phoneLogin"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12936`。
- 请求体：
```javascript
{
                pre: t,
                phone: n,
                msg_code: i
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14889`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-006 nn.accountRegister

- 请求：`POST` `"/v2/nUser/accountRegister"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12945`。
- 请求体：
```javascript
{
                account: t,
                password: n
            }
```
- 特殊配置：
```javascript
{
                timeout: 15e3,
                options: {
                    retryCount: 0
                }
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14243`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-007 nn.accountLogin

- 请求：`POST` `"/nUser/accountLogin"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12959`。
- 请求体：
```javascript
{
                account: t,
                password: n
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14911`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-008 nn.sendSmsCode

- 请求：`POST` `"/nUser/sendMsg"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12967`。
- 请求体：
```javascript
{
                pre: t,
                phone: n,
                tag: i
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1120`；`formatted/dist/assets/index-B33oKSXv.js:14169`；`formatted/dist/assets/index-B33oKSXv.js:14548`；`formatted/dist/assets/index-B33oKSXv.js:14838`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-009 nn.changePassword

- 请求：`POST` `"/nUser/changePassword"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12976`。
- 请求体：
```javascript
{
                pre: t,
                phone: n,
                password: i,
                msg_code: o
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14589`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-010 nn.bindPhone

- 请求：`POST` `"/nUser/bindPhone"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12986`。
- 请求体：
```javascript
{
                pre: t,
                phone: n,
                msg_code: i
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1108`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-011 nn.registerEmail

- 请求：`POST` `"/v2/nUser/mailRegister"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12995`。
- 请求体：
```javascript
{
                mail: t,
                password: n,
                msg_code: i
            }
```
- 特殊配置：
```javascript
{
                timeout: 15e3,
                options: {
                    retryCount: 0
                }
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14228`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-012 nn.sendEmailCode

- 请求：`POST` `"/nUser/mailSendMsg"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13013`。
- 请求体：
```javascript
{
                mail: t,
                type: n
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1138`；`formatted/dist/assets/index-B33oKSXv.js:14192`；`formatted/dist/assets/index-B33oKSXv.js:14560`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-013 nn.bindEmail

- 请求：`POST` `"/nUser/bindMail"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13024`。
- 请求体：
```javascript
{
                mail: t,
                msg_code: n
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1092`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-014 nn.changePasswordEmail

- 请求：`POST` `"/nUser/mailChangePassword"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13032`。
- 请求体：
```javascript
{
                mail: t,
                password: n,
                msg_code: i
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14589`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-015 nn.emailLogin

- 请求：`POST` `"/nUser/mailLogin"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13041`。
- 请求体：
```javascript
{
                mail: t,
                password: n
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:14900`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-016 nn.getCountries

- 请求：`GET` ``${t}/static/json/countries.json``。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13055`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-017 nn.logout

- 请求：`POST` `"/nUser/logout"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13058`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-018 nn.getUserInfo

- 请求：`GET` `"/v2/nUser/getUserInfo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13061`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1486`；`formatted/dist/assets/index-B33oKSXv.js:14876`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-019 nn.bindInviteCode

- 请求：`POST` `"/nUser/bind"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13066`。
- 请求体：
```javascript
{
                invite: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2700`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-020 nn.inviteRecord

- 请求：`GET` `"/nUser/getInviteRecord"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13076`。
- 查询：
```javascript
{
                page: t,
                pageSize: n
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1812`；`formatted/dist/assets/Profile-Cor6JmxC.js:15166`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-021 nn.feedback

- 请求：`POST` `"/feedback"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13089`。
- 请求体：
```javascript
{
                content: t,
                contact: n,
                type: i,
                client: o
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1686`；`formatted/dist/assets/Feedback-HwIxFkQh.js:61`；`formatted/dist/assets/VideoPlayer-9YDDWVER.js:27185`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-022 nn.dailyTask

- 请求：`GET` `"/nUser/todayData"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13099`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2513`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-023 nn.sign

- 请求：`POST` `"/sign/do"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13102`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2545`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-024 nn.getSignCheck

- 请求：`GET` `"/sign/check"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13105`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2556`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-025 nn.signActivity

- 请求：`GET` `"/nUser/signActivity?type=this"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13108`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-026 nn.editUserInfo

- 请求：`POST` `"/nUser/updateUserInfo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13111`。
- 请求体：
```javascript
{
                nickname: t,
                sex: n
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:886`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-027 nn.updateUserHeader

- 请求：`POST` `"/nUser/updateUserInfo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13119`。
- 请求体：
```javascript
{
                avatar_path: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1499`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-028 nn.addComment

- 请求：`POST` `"/comment/add"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13132`。
- 请求体：
```javascript
{
                video_id: t,
                url_id: n,
                content: i,
                type: o,
                reply_comment_id: a
            }
```
- 调用点：`formatted/dist/assets/VideoPlayer-9YDDWVER.js:191`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-029 nn.myVideoCommentList

- 请求：`GET` `"/comment/myVideoList?page=" + t`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13145`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2350`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-030 nn.myReplyComment

- 请求：`GET` `"/comment/myReplyCommentList?page=" + t + "&comment_id=" + n`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13151`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2007`；`formatted/dist/assets/Profile-Cor6JmxC.js:2112`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-031 nn.myReplyCommentList

- 请求：`GET` `"/comment/myCommentList?page=" + t + "&vid=" + n`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13157`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2228`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-032 nn.deleteComment

- 请求：`POST` `"/comment/delete"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13162`。
- 请求体：
```javascript
{
                comment_id: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2127`；`formatted/dist/assets/Profile-Cor6JmxC.js:2243`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-033 nn.addThumb

- 请求：`POST` `"/v2/comment/doFavor"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13171`。
- 请求体：
```javascript
{
                comment_id: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:2102`；`formatted/dist/assets/VideoPlayer-9YDDWVER.js:207`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-034 nn.getVideoCommentList

- 请求：`GET` `"/v2/comment/short/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13183`。
- 查询：
```javascript
{
                page: n,
                url_id: t,
                type: i,
                sort: o,
                pageSize: 20
            }
```
- 调用点：`formatted/dist/assets/ShortVideo-CDQMB1dB.js:511`；`formatted/dist/assets/VideoPlayer-9YDDWVER.js:149`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-035 nn.getLongVideoCommentList

- 请求：`GET` `"/v2/comment/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13197`。
- 查询：
```javascript
{
                video_id: t,
                weight: n,
                sort: o,
                page: i,
                pageSize: 15
            }
```
- 调用点：`formatted/dist/assets/VideoPlayer-9YDDWVER.js:154`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-036 nn.addLongVideoComment

- 请求：`POST` `"/v2/comment/add"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13210`。
- 请求体：
```javascript
{
                video_id: t,
                weight: n,
                content: i,
                reply_comment_id: o
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1998`；`formatted/dist/assets/VideoPlayer-9YDDWVER.js:197`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-037 nn.collectVideo

- 请求：`POST` `"/nUser/collectVideo"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13223`。
- 请求体：
```javascript
{
                id: t,
                type: n
            }
```
- 调用点：`formatted/dist/assets/ShortDetail-Be5VM2Wq.js:194`；`formatted/dist/assets/Detail-D9nBaeLj.js:414`；`formatted/dist/assets/index-B33oKSXv.js:22274`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-038 nn.thumbCommentList

- 请求：`GET` `"/comment/reportOptions"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13231`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-039 nn.thumbComment

- 请求：`POST` `"/comment/report"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13237`。
- 请求体：
```javascript
{
                comment_id: t,
                options: n
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-040 nn.getGiftList

- 请求：`GET` `"/redeem/config/list"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13245`。
- 查询：
```javascript
{
                page: t,
                pageSize: n
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-041 nn.exchangeGift

- 请求：`POST` `"/redeem/gift"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13255`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-042 nn.exchangeVip

- 请求：`POST` `"/nUser/updateVip"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13262`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-043 nn.getGiftDetail

- 请求：`GET` `"/redeem/config/detail"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13265`。
- 查询：
```javascript
{
                id: t
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-044 nn.shareFriend

- 请求：`POST` `"/share/friend"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13272`。
- 调用点：`formatted/dist/assets/MovieViewListDetail-CWLe9dDb.js:88`；`formatted/dist/assets/Profile-Cor6JmxC.js:2637`；`formatted/dist/assets/SpecialDetail-D8YInbxV.js:89`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-045 nn.mobileAreaCode

- 请求：`GET` `"/sms/mobileAreaCode"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13275`。
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:13677`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-046 nn.checkOldPwd

- 请求：`POST` `"/nUser/checkPWD"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13278`。
- 请求体：
```javascript
{
                pwd: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1333`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-047 nn.setNewPwd

- 请求：`POST` `"/nUser/changePWD"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13285`。
- 请求体：
```javascript
{
                pwd: t,
                pwd1: n,
                pwd2: i
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:1320`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-048 nn.redeemGift

- 请求：`POST` `"/redeem/gift"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13300`。
- 请求体：
```javascript
{
                id: t,
                consignee_name: n,
                consignee_phone: i,
                consignee_address: o,
                number: a
            }
```
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-049 nn.getAddressList

- 请求：`GET` `"/address/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13311`。
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:13529`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-050 nn.deleteAddress

- 请求：`POST` `"/address/del"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13314`。
- 请求体：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:13548`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-051 nn.editAddress

- 请求：`POST` `"/address/edit"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13330`。
- 请求体：
```javascript
{
                id: t,
                name: n,
                address: i,
                phone: o,
                province: a,
                city: u,
                zone: c,
                default: f
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:13496`；`formatted/dist/assets/Profile-Cor6JmxC.js:13557`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-052 nn.addAddress

- 请求：`POST` `"/address/add"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13352`。
- 请求体：
```javascript
{
                name: t,
                address: n,
                phone: i,
                province: o,
                city: a,
                zone: u,
                default: c
            }
```
- 调用点：`formatted/dist/assets/Profile-Cor6JmxC.js:13505`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-053 nn.getPackages

- 请求：`GET` `"/v2/pay/packages?type=" + t`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13365`。
- 调用点：`formatted/dist/assets/OpenVip-DpD3mAqH.js:243`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-054 nn.getSwitch

- 请求：`GET` `"/v2/pay/switch"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13368`。
- 调用点：`formatted/dist/assets/OpenVip-DpD3mAqH.js:250`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-055 nn.createVipOrder

- 请求：`POST` `"/v2/pay/createVipOrder"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:13371`。
- 请求体：
```javascript
{
                pay_type: t,
                package_id: n,
                fee: i,
                client: o
            }
```
- 调用点：`formatted/dist/assets/OpenVip-DpD3mAqH.js:229`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

## 广告

### API-001 m7.getAds

- 请求：`GET` `"/v2/advertise/list"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12841`。
- 查询：
```javascript
{
                channel: t,
                client: 3
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:21200`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-002 m7.recordAdShow

- 请求：`POST` `"/v2/advertise/recordShow"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12853`。
- 请求体：
```javascript
{
                ad_id: t,
                pos: n,
                client: 3,
                channel: i
            }
```
- 调用点：`formatted/dist/assets/AdImage-DE4azwlF.js:24`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-003 m7.recordAdClick

- 请求：`POST` `"/v2/advertise/recordClick"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:12867`。
- 请求体：
```javascript
{
                ad_id: t,
                pos: n,
                client: 3,
                channel: i
            }
```
- 调用点：`formatted/dist/assets/AdImage-DE4azwlF.js:36`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

## 配置与更新

### API-056 wo.getHeader

- 请求：`GET` `"/deal/getStr"`。
- 状态：静态 wrapper_only；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:15192`。
- 调用点：未找到；仅保留封装候选。
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-057 wo.getImgDomain

- 请求：`GET` `"/v2/settings/resourceDomainConfig"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:15195`。
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:21471`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-058 wo.getVersion

- 请求：`GET` `"/v2/settings/updateAd"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:15198`。
- 查询：
```javascript
{
                id: t
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:21190`；`formatted/dist/assets/CheckUpdate-DSfI3V6P.js:58`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-059 wo.getConfig

- 请求：`GET` `"/v2/settings/appAuthConfig"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:15205`。
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:21204`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-060 wo.getSysInit

- 请求：`GET` `"/v2/sys/init"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:15208`。
- 特殊配置：
```javascript
{
                options: {
                    noSignature: !0
                }
            }
```
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:21177`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。

### API-061 wo.getAdDomain

- 请求：`GET` `"/v2/settings/advertiseDomainConfig"`。
- 状态：静态 caller_found；动态未验证。
- 定位：`formatted/dist/assets/index-B33oKSXv.js:15217`。
- 调用点：`formatted/dist/assets/index-B33oKSXv.js:21484`
- 响应：公共封装契约；具体字段见主报告消费结构表，未获完整服务端 schema。
